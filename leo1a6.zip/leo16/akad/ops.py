#KAZUMILINE BOT SAMPLE
#Rework By iyo

from gtb import LINE
from datetime import datetime
import time, random, sys, json, codecs, threading, glob, re, string, os, subprocess, ast, timeit, shutil, base64, tempfile, requests
from subprocess import Popen, PIPE, STDOUT
from datetime import datetime
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
import livejson
import asyncio
from threading import Thread
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
countKick = 0
countInvite = 0
countCancel = 0

class ops(object):
    def __init__(self, token = "", type = None):
        try:
            dataPrim = livejson.File('dataPrim.json')
            Mid = ""
            for mid in dataPrim:
                if dataPrim[mid] in token:
                    Mid = mid
            self.client = LINE(token)
            print('success login bot '+str(type))
        except Exception as e:
            if 'code=20' in str(e):
                time.sleep(3600)
                python = sys.executable
                os.execl(python, python, *sys.argv)
            elif 'code=8' in str(e):
                del dataPrim[Mid]
                time.sleep(3600)
                python = sys.executable
                os.execl(python, python, *sys.argv)
            elif 'sent' in str(e):
                python = sys.executable
                os.execl(python, python, *sys.argv)
            elif 'code=35' in str(e):
                self.client.limit = True
            elif str(e) != "":
                print(e)
            sys.exit()
        self.start = time.time()
        self.mid = self.client.profile.mid
        self.set = livejson.File("ops.json")
        self.setws = livejson.File("ws.json")
        self.setbtamp = livejson.File("btamp.json")
        self.comd = livejson.File("comd.json")
        self.tutor = self.comd["tutor"]
        self.setGrade = livejson.File("grade.json")
        self.set["prefix"] = "."
        self.hide = self.comd["comdHide"]
        self.ban = self.set['blacklist']
        self.botOnPro = False
        self.tkn = token
        self.joinQr = False
        self.autoCancel = False
        self.Gid = {}
        self.blacktamp = self.setbtamp['btamp']
        self.AllBotJoin = False
        self.btamQr = {"user":[],"status":False,"input":False}
        self.mainTampBl = self.set['BtamStatus']
        self.botlimit = self.set['botlimit']
        self.checking = self.set['absen']
        self.bots = self.set['bots']
        self.anti = self.set['anti']
        self.owners = self.setGrade['owner']
        self.admin = self.setGrade['admin']
        self.staff = self.setGrade['staff']
        self.gadmin = self.setGrade['Gadmin']
        self.gowner = self.setGrade['Gowner']
        self.gstaff = self.setGrade['Gstaff']
        self.Pgroup = self.setGrade['Pgroup']
        self.bl = self.set['blacklist']
        self.bot = self.set['bots']
        self.gtoken = self.set['gtoken']
        self.foto = False
        self.fotoNum = False
        self.gtb = []
        self.war = self.set['war']
        self.pro = self.set['pro']
        self. fbot = self.set["fbot"]
        self.purge = False
        self.kontak = {}
        self.gname = self.set['gname']
        self.rname = self.set['rname']
        self.sb = self.set['asis']
        self.kickall = False
        self.remotGroup = ""
        self.squad = self.set['squad']
        self.whitlist = self.setws['ws']
        self.sc = "𝘾_𝙁_𝙎 ʙᴇᴛᴀ v2.1.2"
        self.master = ["u1e5aa9ea08d3fb88cd34c7166ec8c4ff"]
        self.main = False
        self.on = True
        self.jqr = True
        self.formatdata = False
        self.limitchange = True
        self.ac = True
        self.capt = 0
        if type != None: self.type = type
        else:self.type = self.bots[self.mid]
        if self.mid not in self.bots:
            self.bots[self.mid] = self.type
        for b in self.sb:
            if self.sb[b] not in self.mid:
                self.gtb.append(self.sb[b])
        if str(self.type) not in self.sb:
            self.sb[str(self.type)] = self.mid
        self.lic = []
        self.nb = str(self.client.getContact(self.mid).displayName)
        nom = 0
        self.timebot = 0
        #self.client.cdk(self.owners)
        self.Lexe = {"auto":False,"lkick":{},"lcancel":{},"lleave":{},"linvite":{},"ljoin":{},"lban":"","lcon":{}}
        stoping = True
        for n in self.sb:
            if stoping == True:
                self.timebot += 0.02
                if nom == self.type:
                    stoping = False
            self.lic.append(nom)
            nom +=1
        self.korban = 0
        self.korban += self.type
        self.maker = [self.client.makerBot]
        self.korban -=1
        if self.type == self.capt:
            if self.pro == {}:pass
            else:self.botOnPro = True
        if self.korban == -1:
            self.korban += len(self.bots)
        self.covid19 =""".1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.

 Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J. Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.
"""
        self.txmainhelp = """𝗕𝘂𝘆𝗲𝗿𝘀

{pref}help buyers
- Commands available for buyers.

𝗢𝘄𝗻𝗲𝗿𝘀

{pref}help owners
- Commands available for owners and higher.

𝗔𝗱𝗺𝗶𝗻𝘀

{pref}help admins
- Commands available for admins and higher.

𝗠𝗼𝗱𝘀

{pref}help mods
- Commands available for mods and higher.""".format(pref=self.set["prefix"])
    def run(self):
        while 1:
            try:
                ops = self.client.poll.fetchOperations(self.client.revision, 5)
                if ops is not None:
                    for op in ops:
                        self.client.revision = max(op.revision, self.client.revision)
                        threading.Thread(target = self.komenbot(op,)).start()
                        if self.purge == True:threading.Thread(target = self.warnormal(op,)).start()
                        else:threading.Thread(target = self.protect(op,)).start()
                        self.getLexe(op)
            except Exception as e: #Exception ValueError
                if 'code=20' in str(e):
                    time.sleep(3600)
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
                elif 'code=8' in str(e):
                    self.client.limit = True
                elif 'code=35' in str(e):
                    self.client.limit = True
                    self.client.Limit()
                elif 'sent' in str(e):
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
                elif 'syncScope=None' in str(e):
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
                elif 'code=73' in str(e):
                    pass
                elif str(e) != "":
                    print(e)
    def pesanbc(self,to, mid, firstmessage, lastmessage):
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    def cek(self, mid):
        if mid not in self.master and mid not in self.owners and mid not in self.bots and mid not in self.whitlist and mid not in self.staff and mid not in self.gtb and mid not in self.anti and mid not in self. fbot and mid not in self.admin and mid not in self.gowner and mid not in self.gadmin and mid not in self.gstaff:
            return True
        else:
            return False
    def acessInTeam(self,grup,user):
        if user in self.gowner or user in self.gadmin or user in self.gstaff:
            if grup in self.Pgroup[user]:
                return True
            else:
                if self.type == self.capt:self.client.sendMessage(grup,"sorry, you can only control bots in the {} group".format(self.client.getGroup(self.Pgroup[user]).name))
                return False
        else:
            if user in self.master or user in self.owners or user in self.admin or user in self.staff or user in self.gtb or user in self.fbot or user in self.anti or user in self.bot:
                return True
            else:
                return False
    def userNotInAccess(self,grup,mid):
        if mid not in self.master and mid not in self.owners and mid not in self.bots and mid not in self.whitlist and mid not in self.staff and mid not in self.gtb and mid not in self.anti and mid not in self. fbot and mid not in self.admin and mid not in self.staff:
            return True
        else:
            if mid in self.gowner or mid in self.gadmin or mid in self.gstaff:
                if grup in self.Pgroup[mid]:
                    return False
                else:
                    if self.type == self.capt:
                        self.client.sendMessage(grup,"sorry, you can only control bots in the {} group".format(self.client.getGroup(self.Pgroup[mid]).name))
                    return True
            return False
    def black(self, mid):
        if mid not in self.master and mid not in self.owners and mid not in self.bots and mid not in self.bl and mid not in self.staff and mid not in self.anti and mid not in self.admin and mid not in self.gowner and mid not in self.gadmin and mid not in self.gstaff:
            self.ban[mid] = True
    def refresh(self):
        self.set = json.load(codecs.open("ops.json","r","utf-8")).copy()
        self.ban = self.set['blacklist']
        self.bots = self.set['bots']
        if self.type == self.capt:
            self.ghost = self.bot.copy()
            del self.ghost[self.mid]
    def save(self):
        pass
    def statusbot(self,to):
        if len(self.set["absen"]) == len(self.sb):
            if self.set["time"] == True:
                tambh = parser.parse(self.set["Timer"])
                timeleft = tambh - datetime.now()
                days, seconds = timeleft.days, timeleft.seconds
                hours = seconds / 3600
                minutes = (seconds / 60) % 60
                mimit = len(self.sb)
                mimit -= len(self.set["botlimit"])
                tx = "Total Bots: {}/{}\n".format(len(self.set["botlimit"]),len(self.bots))
                for bot in self.bots:
                    if bot in self.set["botlimit"]:tx += "{}: Normal\n".format(self.client.getContact(bot).displayName)
                    else:tx += "{}: limit\n".format(self.client.getContact(bot).displayName)
                if self.set["botlimit"] == {}:tx += "Time Remaining: %s Minutes"%(round(minutes))
                else:tx += "Time Remaining: None"
                self.client.sendMessage(to,tx)
            else:
                tambh = parser.parse(self.set["Timer"])
                timeleft = tambh - datetime.now()
                days, seconds = timeleft.days, timeleft.seconds
                hours = seconds / 3600
                minutes = (seconds / 60) % 60
                mimit = len(self.sb)
                mimit -= len(self.set["botlimit"])
                harto = "%s Days, %s Hours, %s Minutes"%(days,round(hours),round(minutes))
                tx = "Total Bots: {}/{}\n".format(len(self.set["botlimit"]),len(self.bots))
                for bot in self.bots:
                    if bot in self.set["botlimit"]:tx += "{}: Normal\n".format(self.client.getContact(bot).displayName)
                    else:tx += "{}: limit\n".format(self.client.getContact(bot).displayName)
                if harto[:1] not in "-":tx += "Time Remaining %s Minutes"%(round(minutes))
                else:tx += "Time Remaining: None"
                self.client.sendMessage(to,tx)
            self.checking.clear()
        else:pass#self.client.sendMessage(self.squad,".helth");time.sleep(1);self.statusbot(to)
    def autoclearwar(self,grup):
        time.sleep(180)
        if self.ban == {}:
            self.main = False
            self.on = True
            self.purge = False
            self.ac = True
            if self.type == self.capt:
                self.war.clear()
            self.limitchange = True
        else:
            if self.type == self.capt:
                self.war.clear()
                self.ban.clear()
                self.set['rname'] = True
                try:self.repleace(grup)
                except:pass
                try:self.client.sendMessage(grup,"auto clear war")
                except:pass
            self.main = False
            self.on = True
            self.purge = False
            self.ac = True
            self.limitchange = True
    def makeBot(self, token, type=1):
        mid = token[:33]
        self.client.findAndAddContactsByMid(mid)
        file = open(mid+".py", "w")
        file.write("from ops import*\nbot = ops('%s')\nbot.run()"%(token))
        file.close()
        self.bots[mid]=type
        self.save()
        threading.Thread(target=os.system,args=('python3.7 %s.py'%mid,)).start()
        for bot in self.ghost:
            self.client.sendMessage(bot,'.add %s_%s'%(mid,type))
        self.refresh()
    def upfoto(self, token):
        file = open("cfoto.py", "w")
        file.write("from upfoto import *\nfrom datetime import datetime, timedelta\nimport time, random, sys, json, codecs, threading, asyncio, glob, re, string, os, six, ast, pytz, atexit, traceback,requests\npub = LINE('{}',appName='IOS\t10.14.0\tiPhone XS\t13.5.1s')\na = 'img.jpg'\ntry:pub.updateProfilePicture(a)\nexcept:pub.updateProfilePicture(a)".format(token))
        file.close()
        time.sleep(self.timebot)
        os.system('python3.6 cfoto.py')
    def invqro(self,gc,b):
        try:
            D = self.client.getGroup(gc)
            if D.preventedJoinByTicket == True:
                D.preventedJoinByTicket = False
                if self.set['rname'] == True:
                    self.gname[gc] = str(D.name)
                    self.set['rname'] = False
                #D.name = str('󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳')
                self.client.updateGroup(D)
            Ticket=self.client.reissueGroupTicket(gc)
            #self.client.sendMessage(self.squad,".join {} {}".format(gc,Ticket))
            if self.client.limit == True:
                if self.limitchange == True:
                    self.client.sendMessage(self.squad,".limit {} {}".format(gc,b))
                    self.limitchange = False
            else:pass
        except Exception as e:
            print(str(e))
    def stayQr(self,ticket):
        if self.client.limit == False:
            self.client.sendMessage(self.squad,".stay {}".format(ticket))
    def invqr(self,tempat):
        grup = self.client.getGroup(tempat)
        if grup.preventedJoinByTicket == True:
            grup.preventedJoinByTicket = False
            self.client.updateGroup(grup)
            Ticket=self.client.reissueGroupTicket(tempat)
            self.stayQr(Ticket)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        out = len(self.bots)
        if matched_list != []:
            pass
        for tag in self.bots:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            out -= len(matched_list)
            if len(matched_list) == len(self.bots):
                self.lockbot(tempat)
            else:self.invqr(tempat)
        else:
            pass
    def repleace(self,tempat):
        A = self.client.getGroupWithoutMembers(tempat)
        A.name = self.gname[tempat]
        self.client.updateGroup(A)
    def lockbot(self,gc):
        try:
            B = self.client.getGroupWithoutMembers(gc)
            if B.preventedJoinByTicket == False:
                B.preventedJoinByTicket = True
                self.client.updateGroup(B)
        except Exception as e:
            print(str(e))
    def kicklockqr(self,tempat,pelaku):
        try:
            self.black(pelaku)
            if self.client.limit == False:
                self.client.kickoutFromGroup(tempat,[pelaku])
                C = self.client.getGroupWithoutMembers(tempat)
                if C.preventedJoinByTicket == False:
                    C.preventedJoinByTicket = True
                    C.name = C.name
                    self.client.updateGroup(C)
            else:
                C = self.client.getGroupWithoutMembers(tempat)
                if C.preventedJoinByTicket == False:
                    C.preventedJoinByTicket = True
                    C.name = C.name
                    self.client.updateGroup(C)
        except Exception as e:
            print(str(e))
    def kicklockban(self,tempat,pelaku):
        try:
            self.black(pelaku)
            if self.client.limit == False:
                self.client.specialKC(tempat,self.ban,[])
                C = self.client.getGroupWithoutMembers(tempat)
                if C.preventedJoinByTicket == False:
                    C.preventedJoinByTicket = True
                    C.name = C.name
                    self.client.updateGroup(C)
            else:
                C = self.client.getGroupWithoutMembers(tempat)
                if C.preventedJoinByTicket == False:
                    C.preventedJoinByTicket = True
                    C.name = C.name
                    self.client.updateGroup(C)
        except Exception as e:
            print(str(e))
    def ccl(self,tempat):
        for x in self.ban:
            self.client.cancelGroupInvitation(tempat,[x])
    def kickcek(self,tempat,pelaku,korban):
        self.black(pelaku)
        if self.client.limit == False:
            self.client.inviteIntoGroup(tempat,self.bot)
            self.client.kickoutFromGroup(tempat,[pelaku])
        else:self.invqro(tempat,korban)
    def kickinv(self,tempat,pelaku,korban):
        self.black(pelaku)
        if self.client.limit == False:
            self.client.kickoutFromGroup(tempat,[pelaku])
            self.client.inviteIntoGroup(tempat,self.bot)
        else:self.invqro(tempat,korban)
    def kickandbl(self,tempat,pelaku):
        self.black(pelaku)
        if self.client.limit == False:
            self.client.kickoutFromGroup(tempat,[pelaku])
    def kicking(self,tempat,pelaku):
        self.black(pelaku)
        if self.client.limit == False:
            self.client.kickoutFromGroup(tempat,[pelaku])
        else:self.broadcast(".prokick {} {}".format(pelaku,tempat))
    def ws(self,mid):
        if mid not in self.owners and mid not in self.bots and mid not in self.whitlist:
            self.setws["ws"][mid] = True
            print("input ws")
    def kickinginv(self,tempat,pelaku,korban):
        if self.userNotInAccess(tempat,pelaku):
            self.black(pelaku)
            if self.client.limit == False:
                self.client.kickoutFromGroup(tempat,[pelaku])
                self.client.findAndAddContactsByMid(korban)
                self.client.inviteIntoGroup(tempat,[korban])
            else:self.broadcast(".prokick {} {}".format(pelaku,tempat))
    def kickplay(self,tempat,pelaku,korban):
        self.black(pelaku)
        if self.set['rname'] == True:
            D = self.client.getGroupWithoutMembers(tempat)
            self.gname[tempat] = str(D.name)
            self.set['rname'] = False
            self.set["war"][tempat] = True
        if self.client.limit == False:
            self.client.inviteIntoGroup(tempat,self.bot)
            self.client.kickoutFromGroup(tempat,[pelaku])
        else:self.invqro(tempat,korban)
    def kickpro(self,tempat,pelaku,korban):
        self.black(pelaku)
        if korban in self.sb[str(self.korban)]:
            if self.cek(pelaku):
                if self.type == self.type:
                    threading.Thread(target = self.inputwarbot(tempat,pelaku,korban)).start()
        else:
            if korban not in self.bots:
                if self.botOnPro == True:
                    self.kickinginv(tempat,pelaku,korban)
    def inputwarbot(self,tempat,pelaku,korban):
        self.black(pelaku)
        if self.on == True:
            self.set["war"][tempat] = True
            #self.main = True
            self.on = False
            self.purge = True
        if self.client.limit == False:
            time.sleep(0.2)
            if self.mainTampBl == True:
                v = []
                for sq in self.blacktamp:
                    if pelaku in self.blacktamp[sq]:
                        for x in self.blacktamp[sq]:
                            self.black(x)
                            v.append(x)
                        break
                if v == []:
                    try:self.client.specialKC(tempat,self.ban,[]);self.client.inviteIntoGroup(tempat,[self.mid])
                    except:self.invqro(tempat,pelaku);self.client.limit = True
                else:
                    try:self.client.specialKC(tempat,v,[]);self.client.inviteIntoGroup(tempat,[self.mid])
                    except:self.invqro(tempat,pelaku);self.client.limit = True
            else:
                try:threading.Thread(target = self.client.specialKC(tempat,self.ban,[])).start();self.client.inviteIntoGroup(tempat,[self.mid])
                except:self.invqro(tempat,pelaku);self.client.limit = True
        else:self.invqro(tempat,pelaku)
    def kicks(self,tempat):
        for x in self.ban:
            self.client.kickoutFromGroup(tempat,[x])
    def dban(self,tempat):
        time.sleep(2)
        grup = self.client.getGroup(tempat)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        if matched_list != []:
            pass
        for tag in self.ban:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            self.client.specialKC(tempat,self.ban,[])
        else:
            pass
    def nuklir(self,tempat):
        grup = self.client.getGroup(tempat)
        self.client.sendMessage(tempat,self.covid19)
        gMembMids = [contact.mid for contact in grup.members]
        x = []
        for z in gMembMids:
            if self.cek(z):
                x.append(z)
        threading.Thread(target = self.client.specialKC(tempat,x,[])).start()
    def kickbl(self,tempat):
        grup = self.client.getGroup(tempat)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        if matched_list != []:
            pass
        for tag in self.ban:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            threading.Thread(target = self.client.specialKC(tempat,self.ban,[])).start()
        else:
            pass
    def detect(self,tempat,pelaku,korban,bottype):
        grup = self.client.getGroup(tempat)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        if matched_list != []:
            pass
        for tag in bottype:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            self.kickplay(tempat,pelaku,korban)
        else:
            pass
    def botInGroup(self,tempat):
        grup = self.client.getGroup(tempat)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        out = len(self.bots)
        if matched_list != []:
            pass
        for tag in self.bots:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            out -= len(matched_list)
            if len(matched_list) == len(self.bots):
                self.lockbot(tempat)
                self.client.sendMessage(tempat,"{}/{} Bots here.".format(str(len(matched_list)), len(self.bots)))
    def inGroupStay(self,grup):
        grup = self.client.getGroup(grup)
        gMembMids = [contact.mid for contact in grup.members]
        bot = []
        for a in self.bot:
            if a not in gMembMids:
                bot.append(a)
        return bot
    def detectbot(self,tempat):
        grup = self.client.getGroup(tempat)
        if grup.preventedJoinByTicket == True:
            grup.preventedJoinByTicket = False
            self.client.updateGroup(grup)
            Ticket=self.client.reissueGroupTicket(tempat)
            self.stayQr(Ticket)
        gMembMids = [contact.mid for contact in grup.members]
        matched_list = []
        out = len(self.bots)
        if matched_list != []:
            pass
        for tag in self.bots:
            matched_list+=filter(lambda str: str == tag, gMembMids)
        if matched_list:
            out -= len(matched_list)
            if len(matched_list) == len(self.bots):
                self.lockbot(tempat)
                self.client.sendMessage(tempat,"{} bot used\ntotal all bots {}".format(str(len(matched_list)),str(len(self.sb))))
            else:self.detectbot(tempat)
        else:
            pass
    def dow(self,mid):
        self.owners.remove(mid)
    def dst(self,mid):
        self.staff.remove(mid)
    def detectSender(self,user):
        if user in self.master:
            return 1
        if user in self.owners:
            return 2
        if user in self.admin:
            return 3
        if user in self.staff:
            return 4
        if user in self.gowner:
            return 5
        if user in self.gadmin:
            return 6
        if user in self.gstaff:
            return 7
        return 0
    def forStaff(self,user):
        if user in self.gadmin or user in self.gowner:
            return True
        else:
            if user in self.master or user in self.owners or user in self.admin or user in self.staff:
                return True
    def permitUser(self,grup,user,com):
        if user in self.gadmin or user in self.gowner or user in self.staff:
            if user in self.gowner:
                if self.gowner[user] == {}:
                    return False
                else:
                    if self.gowner[user][com] == True:
                        if grup in self.Pgroup[user]:
                            return True
                        else:
                            if self.type == self.capt:self.client.sendMessage(grup,"sorry, you can only control bots in the {} group".format(self.client.getGroup(self.Pgroup[user]).name))
                            return False
                    else:
                        return False
            if user in self.gadmin:
                if self.gadmin[user] == {}:
                    return False
                else:
                    if self.gadmin[user][com] == True:
                        if grup in self.Pgroup[user]:
                            return True
                        else:
                            if self.type == self.capt:self.client.sendMessage(grup,"sorry, you can only control bots in the {} group".format(self.client.getGroup(self.Pgroup[user]).name))
                            return False
                    else:
                        return False
            if user in self.gstaff:
                if self.gstaff[user] == {}:
                    return False
                else:
                    if self.gstaff[user][com] == True:
                        if grup in self.Pgroup[user]:
                            return True
                        else:
                            if self.type == self.capt:self.client.sendMessage(grup,"sorry, you can only control bots in the {} group".format(self.client.getGroup(self.Pgroup[user]).name))
                            return False
                    else:
                        return False
        else:
            if user in self.master or user in self.owners or user in self.admin or user in self.staff:
                return True
    def forAdmin(self,user):
        if user in self.gadmin or user in self.gowner:
            return True
        else:
            if user in self.master or user in self.owners or user in self.admin:
                return True
    def forOwners(self,user):
        if user in self.gadmin or user in self.gowner:
            return True
        else:
            if user in self.master or user in self.owners:
                return True
    def forMaster(self,user):
        if user in self.master:
            return True
    def remoteText(self,grup):
        if self.remotGroup == "":
            return
        else:
            if self.type == self.capt:
                self.client.sendMessage(grup,"command has been done in the group {}".format(self.client.getGroup(self.remotGroup).name))
            time.sleep(self.timebot)
            self.remotGroup = ""
    def tutorStaff(self,grup,num):
        tx = []
        for c in self.comd["comdStaff"]:
            if c not in self.hide:
                tx.append(c)
        jwb = tx[int(num)-1]
        if jwb in self.tutor:
            self.client.sendMessage(grup,self.tutor[jwb])
    def tutorAdmin(self,grup,num):
        tx = []
        for b in self.comd["comdAdmin"]:
            if b not in self.hide:
                tx.append(b)
        for c in self.comd["comdStaff"]:
            if c not in self.hide:
                tx.append(c)
        jwb = tx[int(num)-1]
        if jwb in self.tutor:
            self.client.sendMessage(grup,self.tutor[jwb])
    def tutorOwner(self,grup,num):
        tx = []
        for a in self.comd["comdOwner"]:
            if a not in self.hide:
                tx.append(a)
        for b in self.comd["comdAdmin"]:
            if b not in self.hide:
                tx.append(b)
        for c in self.comd["comdStaff"]:
            if c not in self.hide:
                tx.append(c)
        jwb = tx[int(num)-1]
        if jwb in self.tutor:
            self.client.sendMessage(grup,self.tutor[jwb])
    def tutorMaster(self,grup,num):
        tx = []
        for d in self.comd["comdMaster"]:
            if d not in self.hide:
                tx.append(d)
        for a in self.comd["comdOwner"]:
            if a not in self.hide:
                tx.append(a)
        for b in self.comd["comdAdmin"]:
            if b not in self.hide:
                tx.append(b)
        for c in self.comd["comdStaff"]:
            if c not in self.hide:
                tx.append(c)
        jwb = tx[int(num)-1]
        if jwb in self.tutor:
            self.client.sendMessage(grup,self.tutor[jwb])
    def tutorBuyer(self,mid,grup,num):
        if mid in self.setGrade['Gowner']:
            tx = []
            for d in self.setGrade['Gowner'][mid]:
                if d not in self.hide:
                    tx.append(d)
            jwb = tx[int(num)-1]
            if jwb in self.tutor:
                self.client.sendMessage(grup,self.tutor[jwb])
                return
        if mid in self.setGrade['Gadmin']:
            tx = []
            for d in self.setGrade['Gadmin'][mid]:
                if d not in self.hide:
                    tx.append(d)
            jwb = tx[int(num)-1]
            if jwb in self.tutor:
                self.client.sendMessage(grup,self.tutor[jwb])
                return
        if mid in self.setGrade['Gstaff']:
            tx = []
            for d in self.setGrade['Gstaff'][mid]:
                if d not in self.hide:
                    tx.append(d)
            jwb = tx[int(num)-1]
            if jwb in self.tutor:
                self.client.sendMessage(grup,self.tutor[jwb])
                return
    def dellhidecomd(self,num):
        tx = []
        for d in self.hide:
            tx.append(d)
        jwb = tx[int(num)-1]
        if jwb in self.comd["comdHide"]:
            del self.comd["comdHide"][jwb]
            return "command for {} visible now".format(jwb)
        return "please check list number"
    def hidecomd(self,num):
        tx = []
        for d in self.comd["comdMaster"]:
            tx.append(d)
        for a in self.comd["comdOwner"]:
            tx.append(a)
        for b in self.comd["comdAdmin"]:
            tx.append(b)
        for c in self.comd["comdStaff"]:
            tx.append(c)
        jwb = tx[int(num)-1]
        self.hide[jwb] = True
        return "comments for {} hidden now".format(jwb)
    def upcomd(self,num,txt):
        tx = []
        for d in self.comd["comdMaster"]:
            if d not in self.hide:
                tx.append(d)
        for a in self.comd["comdOwner"]:
            if a not in self.hide:
                tx.append(a)
        for b in self.comd["comdAdmin"]:
            if b not in self.hide:
                tx.append(b)
        for c in self.comd["comdStaff"]:
            if c not in self.hide:
                tx.append(c)
        jwb = tx[int(num)-1]
        if jwb in self.comd["comdMaster"]:
            self.comd["comdMaster"][jwb] = str(txt)
            return "{} change to {}\n successfull ".format(jwb,txt)
        else:
            if jwb in self.comd["comdOwner"]:
                ini = self.comd["comdOwner"][jwb]
                self.comd["comdOwner"][jwb] = str(txt)
                return "{} change to {}\n successfull ".format(ini,txt)
            else:
                if jwb in self.comd["comdAdmin"]:
                    ini = self.comd["comdAdmin"][jwb]
                    self.comd["comdAdmin"][jwb] = str(txt)
                    return "{} change to {}\n successfull ".format(ini,txt)
                else:
                    if jwb in self.comd["comdStaff"]:
                        ini = self.comd["comdStaff"][jwb]
                        self.comd["comdStaff"][jwb] = str(txt)
                        return "{} change to {}\n successfull ".format(ini,txt)
        return "please check number list"
    def addComBuyer(self,grade,numB,numC):
        if "gowner" == grade:
            buy = []
            for x in self.gowner:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for d in self.comd["comdMaster"]:
                if d not in self.hide:
                    tx.append(d)
            for a in self.comd["comdOwner"]:
                if a not in self.hide:
                    tx.append(a)
            for b in self.comd["comdAdmin"]:
                if b not in self.hide:
                    tx.append(b)
            for c in self.comd["comdStaff"]:
                if c not in self.hide:
                    tx.append(c)
            nC = tx[int(numC)-1]
            if nC in self.comd["comdMaster"]:
                if tB in self.setGrade['Gowner']:
                    ini = self.comd["comdMaster"][nC]
                    self.setGrade['Gowner'][tB][ini] = True
                    return "adding comment {} to gowner {}, success".format(ini,self.client.getContact(tB).displayName)
            else:
                if nC in self.comd["comdOwner"]:
                    if tB in self.setGrade['Gowner']:
                        ini = self.comd["comdOwner"][nC]
                        self.setGrade['Gowner'][tB][ini] = True
                        return "adding comment {} to gowner {}, success".format(ini,self.client.getContact(tB).displayName)
                else:
                    if nC in self.comd["comdAdmin"]:
                        if tB in self.setGrade['Gowner']:
                            ini = self.comd["comdAdmin"][nC]
                            self.setGrade['Gowner'][tB][ini] = True
                            return "adding comment {} to gowner {}, success".format(ini,self.client.getContact(tB).displayName)
                    else:
                        if nC in self.comd["comdStaff"]:
                            if tB in self.setGrade['Gowner']:
                                ini = self.comd["comdStaff"][nC]
                                self.setGrade['Gowner'][tB][ini] = True
                                return "adding comment {} to gowner {}, success".format(ini,self.client.getContact(tB).displayName)

        if "gstaff" == grade:
            buy = []
            for x in self.staff:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for d in self.comd["comdMaster"]:
                if d not in self.hide:
                    tx.append(d)
            for a in self.comd["comdOwner"]:
                if a not in self.hide:
                    tx.append(a)
            for b in self.comd["comdAdmin"]:
                if b not in self.hide:
                    tx.append(b)
            for c in self.comd["comdStaff"]:
                if c not in self.hide:
                    tx.append(c)
            nC = tx[int(numC)-1]
            if nC in self.comd["comdMaster"]:
                if tB in self.setGrade['Gstaff']:
                    ini = self.comd["comdMaster"][nC]
                    self.setGrade['Gstaff'][tB][ini] = True
                    return "adding comment {} to Gstaff {}, success".format(ini,self.client.getContact(tB).displayName)
            else:
                if nC in self.comd["comdOwner"]:
                    if tB in self.setGrade['Gstaff']:
                        ini = self.comd["comdOwner"][nC]
                        self.setGrade['Gstaff'][tB][ini] = True
                        return "adding comment {} to Gstaff {}, success".format(ini,self.client.getContact(tB).displayName)
                else:
                    if nC in self.comd["comdAdmin"]:
                        if tB in self.setGrade['Gstaff']:
                            ini = self.comd["comdAdmin"][nC]
                            self.setGrade['Gstaff'][tB][ini] = True
                            return "adding comment {} to Gstaff {}, success".format(ini,self.client.getContact(tB).displayName)
                    else:
                        if nC in self.comd["comdStaff"]:
                            if tB in self.setGrade['Gstaff']:
                                ini = self.comd["comdStaff"][nC]
                                self.setGrade['Gstaff'][tB][ini] = True
                                return "adding comment {} to Gstaff {}, success".format(ini,self.client.getContact(tB).displayName)
        if "gadmin" == grade:
            buy = []
            for x in self.gadmin:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for d in self.comd["comdMaster"]:
                if d not in self.hide:
                    tx.append(d)
            for a in self.comd["comdOwner"]:
                if a not in self.hide:
                    tx.append(a)
            for b in self.comd["comdAdmin"]:
                if b not in self.hide:
                    tx.append(b)
            for c in self.comd["comdStaff"]:
                if c not in self.hide:
                    tx.append(c)
            nC = tx[int(numC)-1]
            if nC in self.comd["comdMaster"]:
                if tB in self.setGrade['Gadmin']:
                    ini = self.comd["comdMaster"][nC]
                    self.setGrade['Gadmin'][tB][ini] = True
                    return "adding comment {} to Gadmin {}, success".format(ini,self.client.getContact(tB).displayName)
            else:
                if nC in self.comd["comdOwner"]:
                    if tB in self.setGrade['Gadmin']:
                        ini = self.comd["comdOwner"][nC]
                        self.setGrade['Gadmin'][tB][ini] = True
                        return "adding comment {} to Gadmin {}, success".format(ini,self.client.getContact(tB).displayName)
                else:
                    if nC in self.comd["comdAdmin"]:
                        if tB in self.setGrade['Gadmin']:
                            ini = self.comd["comdAdmin"][nC]
                            self.setGrade['Gadmin'][tB][ini] = True
                            return "adding comment {} to Gadmin {}, success".format(ini,self.client.getContact(tB).displayName)
                    else:
                        if nC in self.comd["comdStaff"]:
                            if tB in self.setGrade['Gadmin']:
                                ini = self.comd["comdStaff"][nC]
                                self.setGrade['Gadmin'][tB][ini] = True
                                return "adding comment {} to Gadmin {}, success".format(ini,self.client.getContact(tB).displayName)
        return "please check list again"
    def dellComBuyer(self,grade,numB,numC):
        if "gowner" == grade:
            buy = []
            for x in self.gowner:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for c in self.gowner[tB]:
                tx.append(c)
            cB = tx[int(numC)-1]
            del self.setGrade['Gowner'][tB][cB]
            return "delete comment {} to gowner {}, success".format(cB,self.client.getContact(tB).displayName)
        if "gadmin" == grade:
            buy = []
            for x in self.gadmin:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for c in self.gadmin[tB]:
                tx.append(c)
            cB = tx[int(numC)-1]
            del self.setGrade['Gadmin'][tB][cB]
            return "delete comment {} to gadmin {}, success".format(cB,self.client.getContact(tB).displayName)
        if "gstaff" == grade:
            buy = []
            for x in self.staff:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = []
            for c in self.gstaff[tB]:
                tx.append(c)
            cB = tx[int(numC)-1]
            del self.setGrade['Gstaff'][tB][cB]
            return "delete comment {} to gstaff {}, success".format(cB,self.client.getContact(tB).displayName)
        return "please check list again"
    def listComBuyer(self,grade,numB):
        if "gowner" == grade:
            buy = []
            for x in self.gowner:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = "𝗚𝗼𝘄𝗻𝗲𝗿𝘀 {}\nGroup: {}\n\n".format(self.client.getContact(tB).displayName,self.client.getGroup(self.Pgroup[tB]).name)
            num = 0
            for c in self.gowner[tB]:
                num += 1
                tx += "⌬ {}. {}{}\n".format(num,c)
            tx += "to delete a comment, type cpermit gowner {} (listcomd)".format(numB)
            return tx
        if "gadmin" == grade:
            buy = []
            for x in self.gadmin:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = "𝗚𝗮𝗱𝗺𝗶𝗻𝘀 {}\nGroup: {}\n\n".format(self.client.getContact(tB).displayName,self.client.getGroup(self.Pgroup[tB]).name)
            num = 0
            for c in self.gadmin[tB]:
                num += 1
                tx += "⌬ {}. {}{}\n".format(num,c)
            tx += "to delete a comment, type cpermit gadmin {} (listcomd)".format(numB)
            return tx
        if "gstaff" == grade:
            buy = []
            for x in self.gstaff:
                buy.append(x)
            tB = buy[int(numB)-1]
            tx = "𝙂𝙨𝙩𝙖𝙛𝙛 {}\nGroup: {}\n\n".format(self.client.getContact(tB).displayName,self.client.getGroup(self.Pgroup[tB]).name)
            num = 0
            for c in self.gstaff[tB]:
                num += 1
                tx += "⌬ {}. {}{}\n".format(num,c)
            tx += "to delete a comment, type cpermit gstaff {} (listcomd)".format(numB)
            return tx
        return "please check list again"
    def dellBuyer(self,grade,numB):
        if "gowner" == grade:
            buy = []
            for x in self.gowner:
                buy.append(x)
            tB = buy[int(numB)-1]
            del self.setGrade['Gowner'][tB]
            del self.setGrade['Pgroup'][tB]
            tx = "𝗚𝗼𝘄𝗻𝗲𝗿𝘀 {}\nHas been delete from list".format(self.client.getContact(tB).displayName)
            return tx
        if "gadmin" == grade:
            buy = []
            for x in self.gadmin:
                buy.append(x)
            tB = buy[int(numB)-1]
            del self.setGrade['Gadmin'][tB]
            del self.setGrade['Pgroup'][tB]
            tx = "𝗚𝗮𝗱𝗺𝗶𝗻𝘀 {}\nHas been delete from list".format(self.client.getContact(tB).displayName)
            return tx
        if "gstaff" == grade:
            buy = []
            for x in self.gstaff:
                buy.append(x)
            tB = buy[int(numB)-1]
            del self.setGrade['Gstaff'][tB]
            del self.setGrade['Pgroup'][tB]
            tx = "𝙂𝙨𝙩𝙖𝙛𝙛 {}\nHas been delete from list".format(self.client.getContact(tB).displayName)
            return tx
        return "please check list again"
    def detectgroup(self,grup):
        groups = self.client.getGroupIdsJoined()
        if grup in groups:
            return True
        else:return False
    def countLexe(self,to,lexe,x):
        num = 0
        ngen = []
        tot = 0
        if "ljoin" == lexe:
            tot += len(self.Lexe["ljoin"][to])
            tot -= int(x)
            for a in self.Lexe["ljoin"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lkick" == lexe:
            tot += len(self.Lexe["lkick"][to])
            tot -= int(x)
            for a in self.Lexe["lkick"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lcancel" == lexe:
            tot += len(self.Lexe["lcancel"][to])
            tot -= int(x)
            for a in self.Lexe["lcancel"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lleave" == lexe:
            tot += len(self.Lexe["lleave"][to])
            tot -= int(x)
            for a in self.Lexe["lleave"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "linvite" == lexe:
            tot += len(self.Lexe["linvite"][to])
            tot -= int(x)
            for a in self.Lexe["linvite"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lcon" == lexe:
            tot += len(self.Lexe["lcon"][to])
            tot -= int(x)
            for a in self.Lexe["lcon"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
    def broadcast(self,text):
        self.client.sendMessage(self.squad,text)
    def notified_receive_message(self,op):
        msg = op.message
        self.capt = self.botType(msg.to)
        if 'MENTION' in msg.contentMetadata.keys() != None:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            for mention in mentionees:
                if mention ['M'] in self.mid:
                    if msg.to in self.pro:
                        if self.cek(msg._from):
                            pass#self.client.kickoutFromGroup(msg.to,[msg._from])
        if 'MENTION' in msg.contentMetadata.keys() != None and self.mid in [x["M"] for x in eval(msg.contentMetadata['MENTION'])["MENTIONEES"]]:
            text = msg.text[int(eval(msg.contentMetadata['MENTION'])["MENTIONEES"][-1]['E'])+1:].replace(' ','')
        else: text = msg.text
        msg_id ,receiver, sender = msg.id ,msg.to ,msg._from
        if msg.toType == 0: to = sender
        else: to = receiver
        if msg.toType == 2:
            if msg.contentType == 13:
                if self.type == self.capt:
                    if self.forStaff(sender):
                        self.kontak[msg.contentMetadata["mid"]] = True
                        if to not in self.Lexe["lcon"]:
                            self.Lexe["lcon"][to] = {msg.contentMetadata["mid"]:True}
                        else:
                            self.Lexe["lcon"][to][msg.contentMetadata["mid"]] = True
                        return
        if text is None:
            return
        if self.remotGroup == "":
            pass
        else:
            to = self.remotGroup
        if msg.toType == 2:
            if msg.contentType == 1:
                if self.foto == True:
                    if self.forOwners(msg._from):
                        if self.type == self.capt:
                            path = self.client.downloadMsg(msg_id, "img.jpg")
                        self.foto = False
                        time.sleep(self.type)
                        self.upfoto(self.tkn)
                        time.sleep(self.type)
                        self.client.sendMessage(to,'Done.')
                if self.fotoNum == True:
                    if self.forOwners(msg._from):
                        path = self.client.downloadMsg(msg_id, "img.jpg")
                        self.fotoNum = False
                        time.sleep(self.type)
                        self.upfoto(self.tkn)
                        time.sleep(self.type)
                        self.client.sendMessage(to,'Done.')
        if sender in self.master:
            rm = threading.Thread(target=self.remoteText, args=(msg.to,)).start()
        if self.type == self.capt:
            if text.lower()== self.set["prefix"]+'help':
                grade = self.detectSender(sender)
                if grade == 1 or grade == 2 or grade == 3 or grade == 4 or grade == 5 or grade == 6 or grade == 7:
                    self.client.sendMessage(to, self.txmainhelp)
            if text.lower() == self.set["prefix"] + 'help buyers':
                grade = self.detectSender(sender)
                if grade == 1:
                    tx = "𝗕𝘂𝘆𝗲𝗿 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀\n\n"
                    for u in self.comd["comdMaster"]:
                        if u not in self.hide:
                            tx += "⌬ {}\n".format(self.comd["comdMaster"][u])
                    self.client.sendMessage(to, tx)
            if text.lower() == self.set["prefix"] + 'help owners':
                grade = self.detectSender(sender)
                if grade == 1 or grade == 2 or grade == 5:
                    tx = "𝗢𝘄𝗻𝗲𝗿 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀\n\n"
                    for u in self.comd["comdOwner"]:
                        if u not in self.hide:
                            tx += "⌬ {}\n".format(self.comd["comdOwner"][u])
                    self.client.sendMessage(to, tx)
            if text.lower() == self.set["prefix"] + 'help admins':
                grade = self.detectSender(sender)
                if grade == 1 or grade == 2 or grade == 3 or grade == 5 or grade == 6:
                    tx = "𝗔𝗱𝗺𝗶𝗻 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀\n\n"
                    for u in self.comd["comdAdmin"]:
                        if u not in self.hide:
                            tx += "⌬ {}\n".format(self.comd["comdAdmin"][u])
                    self.client.sendMessage(to, tx)
            if text.lower() == self.set["prefix"] + 'help mods':
                grade = self.detectSender(sender)
                if grade == 1 or grade == 2 or grade == 3 or grade == 4 or grade == 5 or grade == 6 or grade == 7:
                    tx = "𝗠𝗼𝗱 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀\n\n"
                    for u in self.comd["comdStaff"]:
                        if u not in self.hide:
                            tx += "⌬ {}\n".format(self.comd["comdStaff"][u])
                    self.client.sendMessage(to, tx)
            if text.lower()== self.set["prefix"]+'help2':
                grade = self.detectSender(sender)
                if grade == 1:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙢𝙖𝙨𝙩𝙚𝙧\n"
                    num = 1
                    for u in self.comd["comdMaster"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdMaster"][u])
                            num += 1
                    tx += "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙤𝙬𝙣𝙚𝙧\n"
                    for u in self.comd["comdOwner"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdOwner"][u])
                            num += 1
                    tx += '𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙖𝙙𝙢𝙞𝙣\n'
                    for u in self.comd["comdAdmin"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdAdmin"][u])
                            num += 1
                    tx += "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙨𝙩𝙖𝙛𝙛\n"
                    for u in self.comd["comdStaff"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdStaff"][u])
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 2:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙤𝙬𝙣𝙚𝙧\n"
                    num = 1
                    for u in self.comd["comdOwner"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdOwner"][u])
                            num += 1
                    tx += '𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙖𝙙𝙢𝙞𝙣\n'
                    for u in self.comd["comdAdmin"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdAdmin"][u])
                            num += 1
                    tx += "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙨𝙩𝙖𝙛𝙛\n"
                    for u in self.comd["comdStaff"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdStaff"][u])
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 3:
                    tx = '𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙖𝙙𝙢𝙞𝙣\n'
                    num = 1
                    for u in self.comd["comdAdmin"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdAdmin"][u])
                            num += 1
                    tx += "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙨𝙩𝙖𝙛𝙛\n"
                    for u in self.comd["comdStaff"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdStaff"][u])
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 4:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙨𝙩𝙖𝙛𝙛\n"
                    num = 1
                    for u in self.comd["comdStaff"]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,self.set["prefix"],self.comd["comdStaff"][u])
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 5:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝗚𝗼𝘄𝗻𝗲𝗿𝘀\nonly for group : {}\n\n".format(self.client.getGroup(self.Pgroup[sender]).name)
                    num = 1
                    for u in self.gowner[sender]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,u)
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 6:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝗚𝗮𝗱𝗺𝗶𝗻𝘀\nonly for group : {}\n\n".format(self.client.getGroup(self.Pgroup[sender]).name)
                    num = 1
                    for u in self.gadmin[sender]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,u)
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
                if grade == 7:
                    tx = "𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 𝙂𝙨𝙩𝙖𝙛𝙛\nonly for group : {}\n\n".format(self.client.getGroup(self.Pgroup[sender]).name)
                    num = 1
                    for u in self.gstaff[sender]:
                        if u not in self.hide:
                            tx += "⌬ {}. {}{}\n".format(num,u)
                            num += 1
                    tx += '\nfor more detailed help,\nplease type "*help (num comments)"'
                    self.client.sendMessage(to,tx)
#--------------------------------------------------------------------------------
# For Staff in Captain
        if self.type == self.capt and self.forStaff(sender):
            if text.lower() == self.set["prefix"]+self.comd["comdStaff"]["speed"] and self.permitUser(to,sender,self.comd["comdStaff"]["speed"]):
                start = time.time()
                time.sleep(0.003)
                f = str(time.time() - start)
                b = f[:6]
                self.client.sendMessage(to,b)
            elif text.lower().startswith("*help"):
                split = text.split(" ")
                grade = self.detectSender(sender)
                if grade == 2:
                    self.tutorOwner(to,split[1])
                if grade == 3:
                    self.tutorAdmin(to,split[1])
                if grade == 4:
                    self.tutorStaff(to,split[1])
                if grade == 1:
                    self.tutorMaster(to,split[1])
                if grade == 5 or grade == 6 or grade == 7:
                    self.tutorBuyer(sender,to,split[1])
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdStaff"]["lurk"]) and self.permitUser(to,sender,self.comd["comdStaff"]["lurk"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if to not in self.Gid:
                        self.Gid[to] = []
                        self.client.sendMessage(to,"AutoLurking members on")
                    else:self.client.sendMessage(to,"Already on")
                if "off" == split[1]:
                    if to in self.Gid:
                        del self.Gid[to]
                        self.client.sendMessage(to,"AutoLurking members off")
                    else:self.client.sendMessage(to,"Already off")
            elif text.lower()== self.set["prefix"]+self.comd["comdStaff"]["tagall"] and self.permitUser(to,sender,self.comd["comdStaff"]["tagall"]):
                group = self.client.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(self.client.getProfile().mid)
                self.client.datamention(to,'Mention',nama)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdStaff"]["protect"]) and self.permitUser(to,sender,self.comd["comdStaff"]["protect"]):
                split = text.split(" ")
                if "max" == split[1]:
                    if to not in self.pro:
                        self.set["pro"][to] = True
                        self.botOnPro = True
                        for b in self.client.getGroup(to).invitee:self.ws(b.mid)
                        self.client.sendMessage(to,"Protect maximum enabled.")
                    else:
                        for b in self.client.getGroup(to).invitee:self.ws(b.mid)
                        self.client.sendMessage(to,"Protect is already maximum.");self.botOnPro = True
                if "none" == str(split[1]):
                    if to in self.pro:
                        del self.set["pro"][to]
                        if self.pro == {}:pass
                        else:self.botOnPro = True
                        self.client.sendMessage(to,"Protect disabled.")
                    else:
                        if self.pro == {}:pass
                        else:self.botOnPro = True
                        self.client.sendMessage(to,"Protect already disabled.")
            elif text.lower()== self.set["prefix"]+self.comd["comdStaff"]["me"] and self.permitUser(to,sender,self.comd["comdStaff"]["me"]):
                grade = self.detectSender(sender)
                if grade == 2:
                    self.client.sendMessage(to,"you are an owner.")
                if grade == 3:
                    self.client.sendMessage(to,"you are an admin.")
                if grade == 4:
                    self.client.sendMessage(to,"you are a mod.")
                if grade == 1:
                    self.client.sendMessage(to,"you are a buyer.")
                if grade == 5:
                    self.client.sendMessage(to,"you are a gowner.")
                if grade == 6:
                    self.client.sendMessage(to,"you are a gadmin.")
                if grade == 7:
                    self.client.sendMessage(to,"you are a gmod.")
            elif text.lower()== self.set["prefix"]+self.comd["comdStaff"]["here"] and self.permitUser(to,sender,self.comd["comdStaff"]["here"]):
                self.botInGroup(to)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdStaff"]["mid"]) and self.permitUser(to,sender,self.comd["comdStaff"]["mid"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    for cust in targets:
                        self.client.sendMessage(to, "{}\n{}".format(self.client.getContact(cust).displayName,cust))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for cust in targets:
                    self.client.sendMessage(to, "{}\n{}".format(self.client.getContact(cust).displayName, cust))
# For Staff in All Bots
        if self.type == self.type and self.forStaff(sender):
            if "/ti/g/" in msg.text.lower():
                if self.joinQr == True:
                    link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = link_re.findall(text)
                    n_links = []
                    for l in links:
                        if l not in n_links:
                            n_links.append(l)
                    for ticket_id in n_links:
                        group = self.client.findGroupByTicket(ticket_id)
                        if self.kickall == True:
                            self.client.acceptGroupInvitationByTicket(group.id,ticket_id)
                            self.nuklir(group.id)
                        else:
                            self.client.acceptGroupInvitationByTicket(group.id,ticket_id)
                            self.client.sendMessage(to, "Masuk : %s" % str(group.name))
#--------------------------------------------------------------------------------
# For Admin in Captain
        if self.type == self.capt and self.forAdmin(sender):
            if text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["ban"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["ban"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if cust not in self.ban:
                            if self.cek(cust):
                                self.ban[cust] = True
                                num += 1
                                #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                    self.client.sendMessage(to, "Banned {} users.".format(str(num)))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if cust not in self.ban:
                        if self.cek(cust):
                            self.ban[cust] = True
                            num += 1
                            #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                self.client.sendMessage(to, "Banned {} users.".format(str(num)))
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["unban"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["unban"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if cust in self.ban:
                            if self.cek(cust):
                                del self.ban[cust]
                                num += 1
                                #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                    self.client.sendMessage(to, "Unbanned {} users.".format(str(num)))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if cust in self.ban:
                        del self.ban[cust]
                        num += 1
                        #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                self.client.sendMessage(to, "Unbanned {} users.".format(str(num)))
# Not Working
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["banlist"] and self.permitUser(to,sender,self.comd["comdAdmin"]["banlist"]):
                if self.ban == {}:
                    self.client.sendMessage(to,"No Bans.")
                else:
                    bl = []
                    for s in self.ban:
                        bl.append(s)
                    self.client.datamention(to,'𝗕𝗮𝗻 𝗟𝗶𝘀𝘁',bl)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["clearbans"] and self.permitUser(to,sender,self.comd["comdAdmin"]["clearbans"]):
                mc = "𝗕𝗮𝗻 𝗟𝗶𝘀𝘁\n\n"
                num = 0
                for mid in self.bl:
                    num += 1
                    try:mc += "{} ".format(num) + self.client.getContact(mid).displayName
                    except:mc += "{} ".format(num) + str(mid)
                self.client.sendMessage(to,mc)
                try:self.repleace(to)
                except:pass
                try:self.client.sendMessage(to,"{} user cleared".format(str(len(self.ban))));self.ban.clear()
                except:pass
                self.set['rname'] = True
                self.war.clear()
                #for all
                self.main = False
                self.on = True
                self.purge = False
                self.limitchange = True
                self.broadcast("clearbl")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["mod"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["mod"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if cust not in self.staff:
                            if self.cek(cust):
                                self.staff.append(cust)
                                num += 1
                                #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                    self.client.sendMessage(to, "Promoted {}.".format(str(num)))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if cust not in self.staff:
                        if self.cek(cust):
                            self.staff.append(cust)
                            num += 1
                            #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                self.client.sendMessage(to, "Promoted {}.".format(str(num)))
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["stay"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["stay"]):
                if to in self.squad:self.client.sendMessage(to,"Cant using this Commands in here");return
                split = text.split(" ")
                jmlh = split[1]
                totalbot = []
                for but in self.sb:
                    if self.sb[but] not in self.anti:
                        totalbot.append(self.sb[but])
                if int(jmlh) <= int(len(totalbot)):
                    bot = []
                    batas = True
                    for m in self.lic:
                        if batas == True:
                            bot.append(m)
                            if str(m) in self.sb:
                                if self.sb[str(m)] not in self.bots:
                                    self.bots[self.sb[str(m)]] = m
                            if len(bot) >= int(jmlh):
                                batas = False
                        else:
                            if str(m) in self.sb:
                                if self.sb[str(m)] in self.bots:
                                    del self.bots[self.sb[str(m)]]
                    time.sleep(0.1)
                    b = len(self.bots)
                    b -= 1
                    self.korban = b
                    self.korban = len(self.bots)
                    self.client.sendMessage(self.squad,".leave "+to)
                    try:self.client.inviteIntoGroup(to,self.bots)
                    except:self.client.sendMessage(to,"on limit.")
                else:self.client.sendMessage(to,"Sorry, Total Bots are {}".format(str(len(totalbot))))
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["force"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["force"]):
                if to not in self.squad:
                    split = text.split(" ")
                    jmlh = split[1]
                    totalbot = []
                    for but in self.sb:
                        if self.sb[but] not in self.anti:
                            totalbot.append(self.sb[but])
                    if int(jmlh) <= int(len(totalbot)):
                        bot = []
                        batas = True
                        for m in self.lic:
                            if batas == True:
                                bot.append(m)
                                if str(m) in self.sb:
                                    if self.sb[str(m)] not in self.bots:
                                        self.bots[self.sb[str(m)]] = m
                                if len(bot) >= int(jmlh):
                                    batas = False
                            else:
                                if str(m) in self.sb:
                                    if self.sb[str(m)] in self.bots:
                                        del self.bots[self.sb[str(m)]]
                        time.sleep(0.1)
                        b = len(self.bots)
                        b -= 1
                        self.korban = b
                        D = self.client.getGroupWithoutMembers(to)
                        if D.preventedJoinByTicket == True:
                            D.preventedJoinByTicket = False
                        self.client.updateGroup(D)
                        Ticket=self.client.reissueGroupTicket(to)
                        self.stayQr(Ticket)
                        self.detectbot(to)
                    else:self.client.sendMessage(to,"Sorry, Total Bots are {}".format(str(len(totalbot))))
                else:
                    if self.type == self.capt:
                        self.client.sendMessage(to,"This is Backup Room, Command not allowed here.")
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["lkicks"] and self.permitUser(to,sender,self.comd["comdAdmin"]["lkicks"]):
                if to not in self.Lexe["lkick"]:
                    self.client.sendMessage(to,"Not last kicked in here.")
                else:
                    if self.Lexe["lkick"][to] == {}:
                        self.client.sendMessage(to,"Not last kicked in here.")
                    else:
                        data = [mid for mid in self.Lexe["lkick"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗞𝗶𝗰𝗸𝗲𝗱 𝗛𝗲𝗿𝗲',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["lcons"] and self.permitUser(to,sender,self.comd["comdAdmin"]["lcons"]):
                if to not in self.Lexe["lcon"]:
                    self.client.sendMessage(to,"Not last contacts sent in here.")
                else:
                    if self.Lexe["lcon"][to] == {}:
                        self.client.sendMessage(to,"Not last contacts sent in here.")
                    else:
                        data = [mid for mid in self.Lexe["lcon"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗖𝗼𝗻𝘁𝗮𝗰𝘁𝘀 𝗦𝗲𝗻𝘁',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["linvites"] and self.permitUser(to,sender,self.comd["comdAdmin"]["linvites"]):
                if to not in self.Lexe["linvite"]:
                    self.client.sendMessage(to,"Not last invited in here.")
                else:
                    if self.Lexe["linvite"][to] == {}:
                        self.client.sendMessage(to,"Not last invited in here.")
                    else:
                        data = [mid for mid in self.Lexe["linvite"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗜𝗻𝘃𝗶𝘁𝗲𝗱 𝗛𝗲𝗿𝗲',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["lcancels"] and self.permitUser(to,sender,self.comd["comdAdmin"]["lcancels"]):
                if to not in self.Lexe["lcancel"]:
                    self.client.sendMessage(to,"No last canceled in here.")
                else:
                    if self.Lexe["lcancel"][to] == {}:
                        self.client.sendMessage(to,"No Last canceled in here.")
                    else:
                        data = [mid for mid in self.Lexe["lcancel"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗖𝗮𝗻𝗰𝗲𝗹𝗲𝗱 𝗛𝗲𝗿𝗲',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["lleaves"] and self.permitUser(to,sender,self.comd["comdAdmin"]["lleaves"]):
                if to not in self.Lexe["lleave"]:
                    self.client.sendMessage(to,"No last left in here.")
                else:
                    if self.Lexe["lleave"][to] == {}:
                        self.client.sendMessage(to,"Not last left in here.")
                    else:
                        data = [mid for mid in self.Lexe["lleave"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗟𝗲𝗳𝘁 𝗛𝗲𝗿𝗲',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["ljoins"] and self.permitUser(to,sender,self.comd["comdAdmin"]["ljoins"]):
                if to not in self.Lexe["ljoin"]:
                    self.client.sendMessage(to,"Not last joined in here.")
                else:
                    if self.Lexe["ljoin"][to] == {}:
                        self.client.sendMessage(to,"Not last joined in here.")
                    else:
                        data = [mid for mid in self.Lexe["ljoin"][to]]
                        self.client.datamention(to,'𝗟𝗮𝘀𝘁 𝗝𝗼𝗶𝗻𝗲𝗱 𝗛𝗲𝗿𝗲',data)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["staff"] and self.permitUser(to,sender,self.comd["comdAdmin"]["staff"]):
                jum = 0
                mc = "👑 𝗢𝘄𝗻𝗲𝗿𝘀 👑\n"
                for mid in self.owners:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.owners.remove(mid)
                mc += "\n🎩 𝗔𝗱𝗺𝗶𝗻𝘀 🎩\n"
                for mid in self.admin:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.admin.remove(mid)
                mc += "\n🎓 𝗠𝗼𝗱𝘀 🎓\n"
                for mid in self.staff:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.staff.remove(mid)
                self.client.sendMessage(to,mc)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["protectlist"] and self.permitUser(to,sender,self.comd["comdAdmin"]["protectlist"]):
                mc = "𝗣𝗿𝗼𝘁𝗲𝗰𝘁𝗲𝗱 𝗚𝗿𝗼𝘂𝗽𝘀\n\n"
                num = 0
                for mid in self.pro:
                    num += 1
                    mc += "{}. {}\n".format(num, self.client.getGroup(mid).name)
                mc += "TOTAL: {} Groups.".format(str(len(self.pro)))
                self.client.sendMessage(to,mc)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["runtime"] and self.permitUser(to,sender,self.comd["comdAdmin"]["runtime"]):
                runtime = int(time.time() - self.start)
                texts = "Bots running since "
                if runtime // 86400 != 0:
                    texts += "{} days ".format(runtime // 86400 )
                    runtime = runtime % 86400
                if runtime // 3600 != 0:
                    texts+= "{} hours ".format(runtime // 3600 )
                    runtime = runtime % 3600
                if runtime // 60 != 0:
                    texts += "{} minutes ".format(runtime // 60 )
                texts += "{} seconds".format(runtime % 60)
                self.client.sendMessage(to,texts)
            elif text.lower() == self.set["prefix"]+self.comd["comdAdmin"]["purge"] and self.permitUser(to,sender,self.comd["comdAdmin"]["purge"]):
                self.dban(to)
            elif text.lower() == self.set["prefix"]+self.comd["comdAdmin"]["purgeall"] and self.permitUser(to,sender,self.comd["comdAdmin"]["purgeall"]):
                groups = self.client.getGroupIdsJoined()
                g = []
                for rom in groups:
                    g.append(rom)
                for a in g:
                    try:
                        self.dban(a)
                    except:pass
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["forceall"] and self.permitUser(to,sender,self.comd["comdAdmin"]["forceall"]):
                if msg.toType == 2:
                    bot = self.inGroupStay(to)
                    self.client.inviteIntoGroup(to,bot)
            elif text.lower() == self.set["prefix"]+self.comd["comdAdmin"]["health"] and self.permitUser(to,sender,self.comd["comdAdmin"]["health"]):
                self.client.kick(to,self.mid)
                if self.client.limit == False:
                    if self.mid not in self.set["botlimit"]:
                        self.set["botlimit"][self.mid] = True
                else:
                    if self.mid in self.set["botlimit"]:
                        del self.set["botlimit"][self.mid]
                if self.mid not in self.set["absen"]:
                    self.set["absen"][self.mid] = True
                self.client.sendMessage(self.squad,".helth")
                time.sleep(1)
                self.statusbot(to)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["autocancel"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["autocancel"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if to in self.pro:
                        if self.autoCancel == False:
                            self.autoCancel = True
                            self.client.sendMessage(to,"Autocancel is now on.")
                        else:self.client.sendMessage(to,"Autocancel is already on.")
                    else:self.client.sendMessage(to,"Protect your group first.")
                if "off" == split[1]:
                    if self.autoCancel == True:
                        self.autoCancel = False
                        self.client.sendMessage(to,"Autocancel is now off.")
                    else:self.client.sendMessage(to,"Autocancel is already off.")
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["corona"] and self.permitUser(to,sender,self.comd["comdAdmin"]["corona"]):
                self.client.sendMessage(to,self.covid19)
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["botlist"] and self.permitUser(to,sender,self.comd["comdAdmin"]["botlist"]):
                mc = "𝗦𝗾𝘂𝗮𝗱 𝗕𝗼𝘁𝘀\n"
                num1 = 0
                for mid in self.bots:
                    num1 += 1
                    mc += "{}. {}\n".format(num1, self.client.getContact(mid).displayName)
                mc += "TOTAL: {} Squad Bots\n".format(str(len(self.bots)))
                mc += "\n𝗙𝗿𝗶𝗲𝗻𝗱 𝗕𝗼𝘁𝘀\n"
                num2 = 0
                for b in self.fbot:
                    num2 +=1
                    mc += "{}. {}\n".format(num2, self.client.getContact(b).displayName)
                mc += "TOTAL: {} Friend Bots\n".format(str(len(self.fbot)))
                self.client.sendMessage(to,mc)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["invite"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["invite"]):
                proses = text.split(" ")
                lleave = text.replace(proses[0] + " lleave", "")
                if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                    if "" == lleave:
                        lleave = "1"
                    l = int(lleave)
                    l -= 1
                    hasil = self.countLexe(to,"lleave",l)
                    num = []
                    friend = [i for i in self.client.getAllContactIds()]
                    for a in hasil:
                        if a not in friend:
                            try:
                                self.client.findAndAddContactsByMid(a)
                            except:
                                self.client.sendMessage(to, "Adding on limit.")
                                return
                    self.client.inviteIntoGroup(to,hasil)
                    return
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    hasil = self.countLexe(to,"lcon",l)
                    num = []
                    friend = [i for i in self.client.getAllContactIds()]
                    for a in hasil:
                        if a not in friend:
                            try:
                                self.client.findAndAddContactsByMid(a)
                            except:
                                self.client.sendMessage(to, "Adding on limit.")
                                return
                    self.client.inviteIntoGroup(to,hasil)
                    return
                lcancel = text.replace(proses[0] + " lcancel", "")
                if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                    if "" == lcancel:
                        lcancel = "1"
                    l = int(lcancel)
                    l -= 1
                    hasil = self.countLexe(to,"lcancel",l)
                    num = []
                    friend = [i for i in self.client.getAllContactIds()]
                    for a in hasil:
                        if a not in friend:
                            try:
                                self.client.findAndAddContactsByMid(a)
                            except:
                                self.client.sendMessage(to, "Adding on limit.")
                                return
                    self.client.inviteIntoGroup(to,hasil)
                    return
                lkick = text.replace(proses[0] + " lkick", "")
                if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                    if "" == lkick:
                        lkick = "1"
                    l = int(lkick)
                    l -= 1
                    hasil = self.countLexe(to,"lkick",l)
                    num = []
                    friend = [i for i in self.client.getAllContactIds()]
                    for a in hasil:
                        if a not in friend:
                            try:
                                self.client.findAndAddContactsByMid(a)
                            except:
                                self.client.sendMessage(to, "Adding on limit.")
                                return
                    self.client.inviteIntoGroup(to,hasil)
                    return
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["cancel"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["cancel"]):
                proses = text.split(" ")
                linvite = text.replace(proses[0] + " linvite", "")
                if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                    if "" == linvite:
                        linvite = "1"
                    l = int(linvite)
                    l -= 1
                    hasil = self.countLexe(to,"linvite",l)
                    num = []
                    for a in hasil:
                        self.client.cancelGroupInvitation(to, [a])
                    return
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["kick"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["kick"]):
                proses = text.split(" ")
                ljoin = text.replace(proses[0] + " ljoin", "")
                if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                    if "" == ljoin:
                        ljoin = "1"
                    l = int(ljoin)
                    l -= 1
                    hasil = self.countLexe(to,"ljoin",l)
                    num = []
                    for a in hasil:
                        try:
                            self.client.kickoutFromGroup(to, [a])
                        except:
                            self.client.sendMessage(to, "Kick on limit.")
                            return
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    hasil = self.countLexe(to,"lcon",l)
                    num = []
                    for a in hasil:
                        try:
                            self.client.kickoutFromGroup(to, [a])
                        except:
                            self.client.sendMessage(to, "Kick on limit.")
                            return
                if eval(msg.contentMetadata["MENTION"]) != None:
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    for x in key["MENTIONEES"]:targets.append(x["M"])
                    for cust in targets:
                        if self.cek(cust):
                            self.black(cust)
                            if self.mainTampBl == True:
                                musuh = []
                                for sq in self.blacktamp:
                                    if cust in self.blacktamp[sq]:
                                        for x in self.blacktamp[sq]:
                                            musuh.append(x)
                                if musuh == []:
                                    self.client.kickoutFromGroup(to,[cust])
                                else:
                                    try:self.client.specialKC(to,musuh,[])
                                    except:self.broadcast(".kickout {} {}".format(cust,to));self.client.limit = True
                            else:
                                try:self.client.kickoutFromGroup(to,[cust])
                                except:self.broadcast(".kickout {} {}".format(cust,to));self.client.limit = True
# Fix it
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["expel"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["expel"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    for cust in targets:
                        if cust in self.staff:
                            self.dst(cust)
                            self.client.sendMessage(to,"Expelled.")
                        if cust in self.gstaff:
                            self.setGrade['Gstaff'][cust]
                            self.client.sendMessage(to,"Expelled.")
                        if cust in self.gadmin:
                            del self.setGrade['Gadmin'][cust]
                            self.client.sendMessage(to,"Expelled.")
                        if cust in self.gowner:
                            del self.setGrade['Gowner'][cust]
                            self.client.sendMessage(to,"Expelled.")
                        if cust in self.admin:
                            if sender not in self.admin:
                                self.admin.remove(cust)
                                self.client.sendMessage(to,"Expelled.")
                            else:self.client.sendMessage(to,"Sory, u cant Remove admin, please tell the owners")
                        if cust in self.owners:
                            if sender not in self.admin and sender not in self.owners:
                                self.owners.remove(cust)
                                self.client.sendMessage(to,"Remove owners done")
                            #else:self.client.sendMessage(to,"Sory, u cant Remove owners, please tell the master")
                        return
                        if cust in self.fbot:
                            del self.set["fbot"][cust]
                            self.client.sendMessage(to,"Expelled.")
                        return
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for cust in targets:
                    if cust in self.staff:
                        self.dst(cust)
                        self.client.sendMessage(to,"Expelled.")
                        return
                    if cust in self.gstaff:
                        self.setGrade['Gstaff'][cust]
                        self.client.sendMessage(to,"Expelled.")
                        return
                    if cust in self.gadmin:
                        del self.setGrade['Gadmin'][cust]
                        self.client.sendMessage(to,"Expelled.")
                        return
                    if cust in self.gowner:
                        del self.setGrade['Gowner'][cust]
                        self.client.sendMessage(to,"Expelled.")
                        return
                    if cust in self.admin:
                        if sender not in self.admin:
                            self.admin.remove(cust)
                            self.client.sendMessage(to,"Expelled.")
                        #else:self.client.sendMessage(to,"Sory, u cant Remove admin, please tell the owners")
                        return
                    if cust in self.owners:
                        if sender not in self.admin and sender not in self.owners:
                            self.owners.remove(cust)
                            self.client.sendMessage(to,"Expelled.")
                        #else:self.client.sendMessage(to,"Sory, u cant Remove owners, please tell the master")
                        return
                    if cust in self.fbot:
                        del self.set["fbot"][cust]
                        self.client.sendMessage(to,"Expelled.")
                        return
                self.client.sendMessage(to,"data not found")
# For Admin in All Bot
        if self.type == self.type and self.forAdmin(sender):
            if text.lower().startswith(self.set["prefix"]+self.comd["comdAdmin"]["antijs"]) and self.permitUser(to,sender,self.comd["comdAdmin"]["antijs"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if to not in self.squad:
                        if self.anti == {}:
                            if self.type == self.capt:
                                b = 1
                                a = self.korban
                                a -= b
                                self.korban = a
                            ab = len(self.bots)
                            ab -= 1
                            if to not in self.gname:
                                D = self.client.getGroupWithoutMembers(to)
                                self.gname[to] = str(D.name)
                            if self.type == ab:
                                self.type = 100
                                del self.bots[self.mid]
                                self.anti[self.mid] = self.type
                                self.client.leaveGroup(to)
                            if self.type == self.capt:time.sleep(0.5);self.client.inviteIntoGroup(to,self.anti);self.client.sendMessage(to,"Anti mode on")
                        else:
                            if self.type == 100:
                                self.client.leaveGroup(to)
                                return
                            if self.type == self.capt:
                                if to not in self.gname:
                                    D = self.client.getGroupWithoutMembers(to)
                                    self.gname[to] = str(D.name)
                                try:
                                    G = self.client.getGroup(to)
                                    inviteajs = False
                                    for ajs in G.invitee:
                                        if ajs.mid in self.anti:
                                            self.client.sendMessage(to,"AntiJS mode is already on.")
                                            inviteajs = False
                                            break
                                    else:
                                        inviteajs = True
                                    if inviteajs == True:
                                        self.client.inviteIntoGroup(to,self.anti);self.client.sendMessage(to,"AntiJS mode is now on.")
                                except:
                                    for a in self.anti:
                                        self.client.sendMessage(to,"Contact",{'mid': a},13);self.client.sendMessage(to,"Please invite AntiJS bot.")
                            return
                    else:
                        if self.type == self.capt:
                            self.client.sendMessage(to,"This is Backup Room, Command not allowed here.")
                if "off" == split[1]:
                    if self.type == self.capt:
                        f = len(self.sb)
                        f -= 1
                        e = len(self.bots)
                        if e == f:
                            a = 1
                            b = self.korban
                            b += a
                            self.korban = b
                            self.set["anti"] = {}
                            self.client.sendMessage(self.squad,".antileave")
                            self.client.sendMessage(to,"AntiJS mode is now off.")
                        else:self.client.sendMessage(to,"Please invite all bots first.")
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["ping"] and self.permitUser(to,sender,self.comd["comdAdmin"]["ping"]):
                self.client.sendMessage(to,"pong")
            elif text.lower()== self.set["prefix"]+self.comd["comdAdmin"]["bye"] and self.permitUser(to,sender,self.comd["comdAdmin"]["bye"]):
                if to not in self.squad:
                    self.client.leaveGroup(to)
                else:
                    if self.type == 1:
                        self.client.sendMessage(to,"This is Backup Room, Command not allowed here.")
#--------------------------------------------------------------------------------
# For Owner in Captain
        if self.type == self.capt and self.forOwners(sender):
# Fix killmode, cbtamp, listbtamp
            if text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["killmode"]) and self.permitUser(to,sender,self.comd["comdOwner"]["killmode"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if self.set['BtamStatus'] == False:
                        self.set['BtamStatus'] = True
                        self.client.sendMessage(to,"Kick mode tamp enabled")
                    else:self.client.sendMessage(to,"Kick mode tamp Already enabled")
                if "off" == split[1]:
                    if self.set['BtamStatus'] == True:
                        self.set['BtamStatus'] = False
                        self.client.sendMessage(to,"Kick mode tamp disabled")
                    else:self.client.sendMessage(to,"Kick mode tamp Already disabled")
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["cbtamp"] and self.permitUser(to,sender,self.comd["comdOwner"]["cbtamp"]):
                if self.blacktamp == {}:
                    self.client.sendMessage(to,"Not found")
                else:
                    self.blacktamp.clear()
                    self.client.sendMessage(to,"succes..")
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["listbtamp"] and self.permitUser(to,sender,self.comd["comdOwner"]["listbtamp"]):
                if self.blacktamp == {}:
                    self.client.sendMessage(to,"Data not found")
                else:
                    total = 0
                    tx = "╔─[【BLACK TAMP】]\n"
                    for sq in self.blacktamp:
                        tx += "╠⌬╭「 Squad {} 」\n".format(sq)
                        num = 0
                        for user in self.blacktamp[sq]:
                            num += 1
                            total += 1
                            try:tx += "╠⌬│{}. {}\n".format(num,self.client.getContact(user).displayName)
                            except:del self.blacktamp[sq][user]
                    tx += "╚──────────\nTotal {} Bot {} Squad".format(total,len(self.blacktamp))
                    try:self.client.sendMessage(to,tx)
                    except:self.client.sendMessage(to,"Total {} Bot {} Squad".format(total,len(self.blacktamp)))
# Fix End here
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["autojoin"]) and self.permitUser(to,sender,self.comd["comdOwner"]["autojoin"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if self.AllBotJoin == False:
                        self.AllBotJoin = True
                        self.client.sendMessage(to,"Autojoin is now on.")
                    else:self.client.sendMessage(to,"Autojoin is already on.")
                if "off" == split[1]:
                    if self.AllBotJoin == True:
                        self.AllBotJoin = False
                        self.client.sendMessage(to,"Autojoin is now off.")
                    else:self.client.sendMessage(to,"Autojoin is already off.")
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["cowners"] and self.permitUser(to,sender,self.comd["comdOwner"]["cowners"]):
                num = 0
                for mid in self.owners:
                    num += 1
                    self.client.sendMessage(to,"Contact",{'mid': mid},13)
                    #self.client.sendMessage(to,str(mid))
                self.client.sendMessage(to, "Total {} Owners". format(num))
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["cadmins"] and self.permitUser(to,sender,self.comd["comdOwner"]["cadmins"]):
                num = 0
                for mid in self.admin:
                    num += 1
                    self.client.sendMessage(to,"Contact",{'mid': mid},13)
                    #self.client.sendMessage(to,str(mid))
                self.client.sendMessage(to, "Total {} Admins".format(num))
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["cmods"] and self.permitUser(to,sender,self.comd["comdOwner"]["cmods"]):
                num = 0
                for mid in self.staff:
                    num += 1
                    self.client.sendMessage(to,"Contact",{'mid': mid},13)
                    #self.client.sendMessage(to,str(mid))
                self.client.sendMessage(to, "Total {} Mods".format(num))
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["cbots"] and self.permitUser(to,sender,self.comd["comdOwner"]["cbots"]):
                num = 0
                for mid in self.bots:
                    self.client.sendMessage(to,"Contact",{'mid': mid},13)
                    #self.client.sendMessage(to,str(mid))
                self.client.sendMessage(to, "Total {} Bots".format(num))
            elif text.lower() == self.set["prefix"]+self.comd["comdOwner"]["nuke"] and self.permitUser(to,sender,self.comd["comdOwner"]["nuke"]):
                self.nuklir(to)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["members"]) and self.permitUser(to,sender,self.comd["comdOwner"]["members"]):
                split = text.split(" ")
                number = text.replace(split[0] + " ","")
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(number)-1]
                    G = self.client.getGroup(group)
                    jembut = [contact.mid for contact in G.members]
                    tx = "𝗠𝗲𝗺𝗯𝗲𝗿𝘀 𝗼𝗳 "+self.client.getGroup(group).name+"\n\n"
                    num = 1
                    for mid in jembut:
                        tx += "{}. {}\n".format(str(num),self.client.getContact(mid).displayName)
                        num += 1
                    tx += "Total: {} Members.".format(str(len(jembut)))
                    self.client.sendMessage(to,tx)
                except Exception as e:
                    print (e)
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["groups"] and self.permitUser(to,sender,self.comd["comdOwner"]["groups"]):
                groups = self.client.getGroupIdsJoined()
                tx = "𝗚𝗿𝗼𝘂𝗽𝘀\n"
                num = 0
                for gc in groups:
                    num += 1
                    tx += "{}.{}\n".format(num,self.client.getGroup(gc).name)
                tx += "Total {} Groups".format(num)
                self.client.sendMessage(to,tx)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["ourl"]) and self.permitUser(to,sender,self.comd["comdOwner"]["ourl"]):
                split = text.split(" ")
                number = text.replace(split[0] + " ","")
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(number)-1]
                    G = self.client.getGroup(group)
                    G.preventedJoinByTicket = False
                    Ticket = self.client.reissueGroupTicket(group)
                    self.client.updateGroup(G)
                    self.client.sendMessage(to,"{}\nhttps://line.me/R/ti/g/{}".format(self.client.getGroup(group).name,str(Ticket)))
                except Exception as e:
                    print (e)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["inviteto"]) and self.permitUser(to,sender,self.comd["comdOwner"]["inviteto"]):
                split = text.split(" ")
                number = text.replace(split[0] + " ","")
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(number)-1]
                    self.client.inviteIntoGroup(group,[sender])
                except Exception as e:
                    self.client.sendMessage(to,"Invite on limit.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["rkick"]) and self.permitUser(to,sender,self.comd["comdOwner"]["rkick"]):
                split = text.split(" ")
                grup = split[1]
                nk0 = split[2]
                nk1 = nk0.lstrip()
                nk2 = nk1.replace("","")
                nk3 = nk2.rstrip()
                mid = nk3
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(grup)-1]
                    G = self.client.getGroup(group)
                    jembut = [contact.mid for contact in G.members]
                    target = jembut[int(mid)-1]
                    if self.cek(target):
                        try:
                            self.client.kickoutFromGroup(group,[target])
                            self.black(target)
                            self.client.sendMessage(to,"Kicked "+self.client.getContact(target).displayName)
                        except:self.broadcast(".rkickout {} {}".format(target,group))
                except Exception as e:
                    print (e)

# Fix Broadcast
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["broadcast"]) and self.permitUser(to,sender,self.comd["comdOwner"]["broadcast"]):
                split = text.split(" ")
                groups = self.client.getGroupIdsJoined()
                name = self.client.getContact(sender).displayName
                g = []
                for rom in groups:
                    g.append(rom)
                for a in g:
                    try:
                        self.pesanbc(a,sender,"𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁\nby:","\n\n{}".format(split[1]))
                        time.sleep(1)
                    except:pass
                self.client.sendMessage(to,"Broadcast sent to {} groups.".format(len(g)))
##
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["add fbot"] and self.permitUser(to,sender,self.comd["comdOwner"]["add fbot"]):
                grup = self.client.getGroup(to)
                membergrup = [contact.mid for contact in grup.members]
                list = 0
                for mid in membergrup:
                    if self.cek(mid):
                        self.set["fbot"][mid] = True
                        list += 1
                        time.sleep(0.2)
                self.client.sendMessage(to,"Succes {} user add to friend".format(str(list)))
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["dell fbot"] and self.permitUser(to,sender,self.comd["comdOwner"]["dell fbot"]):
                self.fbot.clear()
                self.whitlist.clear()
                self.client.sendMessage(to,"done")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["afbot"]) and self.permitUser(to,sender,self.comd["comdOwner"]["afbot"]):
                if sender in self.master or sender in self.owners:
                    proses = text.split(" ")
                    lcon = text.replace(proses[0] + " lcon", "")
                    if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    	if "" == lcon:
                    		lcon = "1"
                    	l = int(lcon)
                    	l -= 1
                    	hasil = self.countLexe(to,"lcon",l)
                    	for a in hasil:
                    		if a not in self.fbot:
                    			self.set["fbot"][a] = True
                    			self.client.sendMessage(to,"add friend success")
                    		else:self.client.sendMessage(to,"sudah terdaftar")
                    if None == eval(msg.contentMetadata["MENTION"]):return
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for cust in targets:
                        if cust not in self.fbot:
                            self.set["fbot"][cust] = True
                            self.client.sendMessage(to,"add friend success")
                        else:self.client.sendMessage(to,"sudah terdaftar")
                else:self.client.sendMessage(to,"who are you?")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["dfbot"]) and self.permitUser(to,sender,self.comd["comdOwner"]["dfbot"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                	if "" == lcon:
                		lcon = "1"
                	l = int(lcon)
                	l -= 1
                	hasil = self.countLexe(to,"lcon",l)
                	for a in hasil:
                		if a in self.fbot:
                			del self.set["fbot"][a] 
                			self.client.sendMessage(to,"dellete friend success")
                		else:self.client.sendMessage(to,"belum terdaftar")
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for cust in targets:
                    if cust in self.fbot:
                        del self.set["fbot"][cust]
                        self.client.sendMessage(to,"delete friend success")
                    else:self.client.sendMessage(to,"sudah terhapus")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["jointicket"]) and self.permitUser(to,sender,self.comd["comdOwner"]["jointicket"]):
                split = text.split(" ")
                if "on" == split[1]:
                    if self.joinQr == False:
                        self.joinQr = True
                        self.broadcast(".jointicket on")
                        self.client.sendMessage(to, "Join with Qr enabled.")
                    else:self.client.sendMessage(to, "Join with Qr already enabled.")
                if "off" == split[1]:
                    if self.joinQr == True:
                        self.joinQr = False
                        self.broadcast(".jointicket off")
                        self.client.sendMessage(to, "Join with Qr disabled.")
                    else:self.client.sendMessage(to, "Join with Qr already disabled.")
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["uimageall"] and self.permitUser(to,sender,self.comd["comdOwner"]["uimageall"]):
                self.foto = True
                self.broadcast(".upfoto")
                self.client.sendMessage(to, "Please send an image.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["protectgrp"]) and self.permitUser(to,sender,self.comd["comdOwner"]["protectgrp"]):
                split = text.split(" ")
                number = text.replace(split[0] + " ","")
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(number)-1]
                    if group not in self.set["pro"]:
                        self.set["pro"][group] = True
                        for b in self.client.getGroup(group).invitee:self.ws(b.mid)
                        self.client.sendMessage(to,"Protection enabled for "+str(self.client.getGroup(group).name))
                    else:self.client.sendMessage(to,"Protection already enabled for "+str(self.client.getGroup(group).name))
                except Exception as e:
                    print (e)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["unprotectgrp"]) and self.permitUser(to,sender,self.comd["comdOwner"]["unprotectgrp"]):
                split = text.split(" ")
                number = text.replace(split[0] + " ","")
                groups = self.client.getGroupIdsJoined()
                try:
                    group = groups[int(number)-1]
                    if group in self.set["pro"]:
                        del self.set["pro"][group]
                        self.client.sendMessage(to,"Protection disabled for "+str(self.client.getGroup(group).name))
                    else:self.client.sendMessage(to,"Protection already disabled for "+str(self.client.getGroup(group).name))
                except Exception as e:
                    print (e)
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["wl"] and self.permitUser(to,sender,self.comd["comdOwner"]["wl"]):
                if self.type == self.capt:
                    if self.setws['ws'] == {}:
                        self.client.sendMessage(to,"Not Found")
                    else:
                        wl = []
                        for s in self.setws['ws']:
                            wl.append(s)
                        if wl == []:
                            self.client.sendMessage(to,"mid eror.")
                        else:
                            self.client.datamention(to,'𝗪𝗵𝗶𝘁𝗲 𝗟𝗶𝘀𝘁',wl)
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["clearwl"] and self.permitUser(to,sender,self.comd["comdOwner"]["clearwl"]):
                if self.type == self.capt:
                    if self.setws['ws'] == {}:
                        self.client.sendMessage(to,"Not Found")
                    else:
                        tx = "𝗪𝗵𝗶𝘁𝗲 𝗟𝗶𝘀𝘁\n"
                        num = 0
                        for s in self.setws['ws']:
                            num += 1
                            try:tx += "{}. {}\n".format(num,self.client.getContact(s).displayName)
                            except:pass
                        self.client.sendMessage(to,tx+"Total {} users cleared.".format(len(self.setws['ws'])))
                        self.whitlist.clear()
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["admin"]) and self.permitUser(to,sender,self.comd["comdOwner"]["admin"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if cust not in self.admin:
                            if self.cek(cust):
                                self.admin.append(cust)
                                num += 1
                                #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                    self.client.sendMessage(to, "Promoted {}.".format(str(num)))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if cust not in self.admin:
                        if self.cek(cust):
                            self.admin.append(cust)
                            num += 1
                            #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                self.client.sendMessage(to, "Promoted {}.".format(str(num)))

# For Owner in All Bots
        if self.type == self.type and self.forOwners(sender):
            if text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["nukejoin"]+str(self.type)) and self.permitUser(to,sender,self.comd["comdOwner"]["nukejoin"]):
                split = text.split(" ")
                if "off" == split[1]:
                    if self.kickall == True:
                        self.kickall = False
                        self.client.sendMessage(to,"Nuke group upon joining is now off.")
                    else:self.client.sendMessage(to,"Nuke group upon joining is already off.")
                if "on" == split[1]:
                    if self.kickall == False:
                        self.kickall = True
                        self.client.sendMessage(to,"Nuke group upon joining is now on.")
                    else:self.client.sendMessage(to,"Nuke group upon joining is already off.")
            elif text.lower()== self.set["prefix"]+self.comd["comdOwner"]["status"] and self.permitUser(to,sender,self.comd["comdOwner"]["status"]):
                tx = "𝗕𝗼𝘁𝘀 𝗦𝘁𝗮𝘁𝘂𝘀\n"
                if self.client.limit == True:tx += "Status: Down\n"
                else:tx += "Status: Normal\n"
                if self.main == True:tx += "War : Aktive\n"
                else:tx += "War: Sleep\n"
                if self.set['BtamStatus'] == True:tx += "Kick Mode: BlackSquad\n"
                else:tx += "Kic Mode: Purge\n"
                if self.anti == {}:tx += "AJS Mode: Off\n"
                else: "• AJS Mode: ON\n"
                self.client.sendMessage(to, tx)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["uimage"]+str(self.type)) and self.permitUser(to,sender,self.comd["comdOwner"]["uimage"]):
                self.fotoNum = True
                self.client.sendMessage(to,"Please send an image.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["uname"]+str(self.type)) and self.permitUser(to,sender,self.comd["comdOwner"]["uname"]):
                split = text.split(": ")
                b = self.client.getProfile()
                b.displayName = "{}".format(split[1])
                self.client.updateProfile(b)
                self.client.sendMessage(to,"Done.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["unameall"]) and self.permitUser(to,sender,self.comd["comdOwner"]["unameall"]):
                split = text.split(": ")
                b = self.client.getProfile()
                b.displayName = "{}{}".format(split[1],self.type)
                self.client.updateProfile(b)
                self.client.sendMessage(to,"Done.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["ustatus"]) and self.permitUser(to,sender,self.comd["comdOwner"]["ustatus"]):
                split = text.split(" ")
                b = self.client.getProfile()
                b.statusMessage = "{}".format(split[1])
                self.client.updateProfile(b)
                self.client.sendMessage(to,"ok")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdOwner"]["say"]) and self.permitUser(to,sender,self.comd["comdOwner"]["say"]):
                split = text.split(" ")
                self.client.sendMessage(to,split[1])
#--------------------------------------------------------------------------------
# For Buyer in Captain
        if self.type == self.capt and self.forMaster(sender):
            if text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["owner"]) and self.permitUser(to,sender,self.comd["comdMaster"]["owner"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if cust not in self.owners:
                            if self.cek(cust):
                                self.owners.append(cust)
                                num += 1
                                #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                    self.client.sendMessage(to, "Promoted {}.".format(str(num)))
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if cust not in self.owners:
                        if self.cek(cust):
                            self.owners.append(cust)
                            num += 1
                            #self.client.sendMessage(to, "Contact", {'mid': cust}, 13)
                self.client.sendMessage(to, "Promoted {}.".format(str(num)))
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["silent"]):
                if sender in self.maker:
                    split = text.split(" ")
                    number = text.replace(split[0] + " ","")
                    groups = self.client.getGroupIdsJoined()
                    try:
                        group = groups[int(number)-1]
                        self.remotGroup = str(group)
                        if self.type == self.capt:
                            self.client.sendMessage(to,"Your command?")
                    except Exception as e:
                        print (e)
            elif text.lower() == self.set["prefix"]+self.comd["comdMaster"]["squadroom"]:
                self.set["squad"] = str(to)
                self.client.sendMessage(to,"This group is set as Squadroom now.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["upcom"]) and self.permitUser(to,sender,self.comd["comdMaster"]["upcom"]):
                split = text.split(" ")
                num = split[1]
                txt = split[2]
                changed = self.upcomd(num,txt)
                self.client.sendMessage(to,changed)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["hidecom"]):
                split = text.split(" ")
                num = split[1]
                changed = self.hidecomd(num)
                self.client.sendMessage(to,changed)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["unhidecom"]):
                split = text.split(" ")
                num = split[1]
                dell = self.dellhidecomd(num)
                self.client.sendMessage(to,dell)
            elif text.lower() == self.set["prefix"]+self.comd["comdMaster"]["hiddencommands"]:
                if self.hide == {}:
                    self.client.sendMessage(to,"no hidden commands")
                else:
                    tx = "h̶i̶d̶d̶e̶n̶ ̶c̶o̶m̶m̶a̶n̶d̶s̶\n"
                    num = 1
                    for a in self.hide:
                        tx += "{}. {}\n".format(num,a)
                        num += 1
                    tx += "\nTo display commands, please type ({} [number])".format(self.comd["comdMaster"]["unhidecom"])
                    self.client.sendMessage(to,tx)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["gowner"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if self.cek(cust):
                            self.setGrade['Gowner'][cust] = {}
                            self.setGrade['Pgroup'][cust] = str(to)
                            num += 1
                            self.client.sendMessage(to, "Promoted {}".format(str(num)))
                        else:self.client.sendMessage(to, "Already a Gowner.")
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if self.cek(cust):
                        self.setGrade['Gowner'][cust] = {}
                        self.setGrade['Pgroup'][cust] = str(to)
                        num += 1
                        self.client.sendMessage(to,"Promoted {}".format(str(num)))
                    else:self.client.sendMessage(to,"Already a Gowner.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["gadmin"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if self.cek(cust):
                            self.setGrade['Gadmin'][cust] = {}
                            self.setGrade['Pgroup'][cust] = str(to)
                            num += 1
                            self.client.sendMessage(to, "Promoted {}".format(str(num)))
                        else:self.client.sendMessage(to, "Already a Gadmin.")
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if self.cek(cust):
                        self.setGrade['Gadmin'][cust] = {}
                        self.setGrade['Pgroup'][cust] = str(to)
                        num += 1
                        self.client.sendMessage(to,"Promoted {}".format(str(num)))
                    else:self.client.sendMessage(to,"Already a Gadmin.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["gmod"]):
                proses = text.split(" ")
                lcon = text.replace(proses[0] + " lcon", "")
                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                    if "" == lcon:
                        lcon = "1"
                    l = int(lcon)
                    l -= 1
                    targets = self.countLexe(to,"lcon",l)
                    num = 0
                    for cust in targets:
                        if self.cek(cust):
                            self.setGrade['Gmod'][cust] = {}
                            self.setGrade['Pgroup'][cust] = str(to)
                            num += 1
                            self.client.sendMessage(to, "Promoted {}".format(str(num)))
                        else:self.client.sendMessage(to, "Already a Gmod.")
                if None == eval(msg.contentMetadata["MENTION"]):return
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                num = 0
                for cust in targets:
                    if self.cek(cust):
                        self.setGrade['Gmod'][cust] = {}
                        self.setGrade['Pgroup'][cust] = str(to)
                        num += 1
                        self.client.sendMessage(to,"Promoted {}".format(str(num)))
                    else:self.client.sendMessage(to,"Already a Gmod.")
            elif text.lower()== self.set["prefix"]+self.comd["comdMaster"]["gstaff"]:
                jum = 0
                mc = "👑 𝗚-𝗢𝘄𝗻𝗲𝗿𝘀 👑\n"
                for mid in self.gowner:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.owners.remove(mid)
                mc += "\n🎩 𝗚-𝗔𝗱𝗺𝗶𝗻𝘀 🎩\n"
                for mid in self.gadmin:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.admin.remove(mid)
                mc += "\n🎓 𝗚-𝗠𝗼𝗱𝘀 🎓\n"
                for mid in self.gstaff:
                    jum += 1
                    try:mc += "{}. {}\n".format(jum, self.client.getContact(mid).displayName)
                    except:self.staff.remove(mid)
                self.client.sendMessage(to,mc)
            elif text.lower()== self.set["prefix"]+self.comd["comdMaster"]["cleargstaff"]:
                self.setGrade['Pgroup'].clear()
                self.setGrade['Gowner'].clear()
                self.setGrade['Gadmin'].clear()
                self.setGrade['Gstaff'].clear()
                self.client.sendMessage(to,"All G-Staff has been removed.")
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["lpermit"]):
                split = text.split(" ")
                buyer = split[1]
                numbuyer = split[2]
                a = self.listComBuyer(buyer,numbuyer)
                self.client.sendMessage(to,a)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["permit"]):
                split = text.split(" ")
                buyer = split[1]
                numbuyer = split[2]
                numcom = split[3]
                a = self.addComBuyer(buyer,numbuyer,numcom)
                self.client.sendMessage(to,a)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["cpermit"]):
                split = text.split(" ")
                buyer = split[1]
                numbuyer = split[2]
                numcom = split[3]
                a = self.dellComBuyer(buyer,numbuyer,numcom)
                self.client.sendMessage(to,a)
            elif text.lower().startswith(self.set["prefix"]+self.comd["comdMaster"]["prefix"]):
                split = text.split(" ")
                prefix = split[1]
                self.set["prefix"] = prefix
                self.client.sendMessage(to,"Prefix is set to ({})".format(prefix))
            elif text.lower()== self.set["prefix"]+self.comd["comdMaster"]["replacebot"] and self.permitUser(to,sender,self.comd["comdMaster"]["replacebot"]):
                        if msg.toType == 2:
                            for gc in self.pro:
                                try:
                                    G = self.client.getGroupWithoutMembers(gc)
                                    if G.preventedJoinByTicket == True:
                                        G.preventedJoinByTicket = False
                                    try:self.client.updateGroup(G)
                                    except:G.name = str("Correct the group name please.");self.client.updateGroup(G)
                                    Ticket=self.client.reissueGroupTicket(gc)
                                    self.client.sendMessage(self.squad,".join {} {}".format(gc,Ticket))
                                    self.detectbot(gc)
                                except:del self.pro[gc]
                            self.client.sendMessage(to,"Bots replaced in group:\n{}".format(str(len(self.pro))))
            elif text.lower()== self.set["prefix"]+self.comd["comdMaster"]["reboot"] and self.permitUser(to,sender,self.comd["comdMaster"]["reboot"]):
                self.client.sendMessage(to,"For confirm, type (ok)")
                self.formatdata = True
            elif text.lower() == 'ok':
                if self.formatdata == True:
                    self.formatdata = False
                    self.set["anti"] = {}
                    self.client.sendMessage(to,"BOT RESTARTING...")
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
# For Buyer in All Bots
        if self.type == self.type and self.forMaster(sender):        	
            if text.lower()== self.set["prefix"]+self.comd["comdMaster"]["byeall"]:
                gc = self.client.getGroupIdsJoined()
                for a in gc:
                    if a not in self.squad and a not in self.pro and a not in to:
                        self.client.leaveGroup(a)
                if self.type == self.capt:
                    self.client.sendMessage(to, "Squad left all groups.")
            elif text.lower()== '.refresh':
                if sender in self.master:
                    if self.type == self.capt:
                        self.client.sendMessage(to,"Seriously? All data will be lost.")
                        self.formatdata = True
                    else:self.formatdata = True
                else:
                    if self.type == self.capt:
                        self.client.sendMessage(to,"sorry, your grade is only owner and admin, this command for master")
            elif text.lower() == '.yes':
                if self.formatdata == True:
                    self.formatdata = False
                    if self.type == self.capt:
                        sec = len(self.bots)
                        sec += len(self.bots)
                        self.setGrade['staff'] = []
                        self.setGrade['admin'] = []
                        self.setGrade['owner'] = []
                        self.set["anti"] = {}
                        for f in self.pro:
                            del self.set["pro"][f]
                        self.set["squad"] = str(to)
                        self.bots.clear()
                        self.sb.clear()
                        self.ban.clear()
                        self.whitlist.clear()
                        self.gname.clear()
                        self.botlimit.clear()
                        self.client.sendMessage(to,"Your system reboting....\nwait for {} seconds, and do the .reboot again".format(str(sec)))
                        time.sleep(2)
                        python = sys.executable
                        os.execl(python, python, *sys.argv)
            elif text.lower() == self.set["prefix"]+self.comd["comdMaster"]["addsquad"]:
                if sender in self.maker:
                    kontak = [cont for cont in self.client.getAllContactIds()]
                    for b in self.bots:
                        if b not in self.mid and b not in kontak:
                            try:self.client.findAndAddContactsByMid(b);time.sleep(1)
                            except Exception as e:
                                print(str(e))
                                self.client.sendMessage(to,"Adding on limit.\nPlease change token.");return
                    self.client.sendMessage(to,"All bot contacts are added.")
#--------------------------------------------------------------------------------
# Squad Communication
        if sender in self.bots:
            if text.lower().startswith('.join '):
                a = self.detectgroup(text[6:39])
                if False == a:
                    threading.Thread(target = self.accqr(text[6:39],text[40:])).start()
            elif text.lower().startswith('.leave'):
                split = text.split(" ")
                mid = split[1]
                if self.mid not in self.bots:
                    d = self.detectgroup(mid)
                    if True == d:
                        self.client.leaveGroup(mid)
                    self.jqr = False
                else:self.jqr = True
            elif text.lower() == '.antileave':
                if self.type == 100:
                    ginvited = self.client.getGroupIdsInvited()
                    ab = len(self.bots)
                    self.bots[self.mid] = ab
                    self.type = ab
                    for g in ginvited:
                        self.client.acceptGroupInvitation(g)
            elif text.lower() == '.upfoto':
                self.foto = True
            elif text.lower() == 'clearbl':
                self.main = False
                self.on = True
                self.purge = False
                self.limitchange = True
            elif text.lower() == '.helth':
                if self.mid not in self.set["absen"]:
                    time.sleep(self.timebot)
                    self.client.kick(to,self.mid)
                    if self.client.limit == False:
                        if self.mid not in self.set["botlimit"]:
                            self.set["botlimit"][self.mid] = True
                    else:
                        if self.mid in self.set["botlimit"]:
                            del self.set["botlimit"][self.mid]
                    self.set["absen"][self.mid] = True
            elif text.lower().startswith('.jointicket'):
                if self.client.limit == False:
                    split = text.split(" ")
                    if "on" == split[1]:
                        self.joinQr = True
                    if "off" == split[1]:
                        self.joinQr = False
            elif text.lower().startswith('.stay'):
                if self.client.limit == False:
                    split = text.split(" ")
                    mid = split[1]
                    grup = self.client.findGroupByTicket(mid)
                    if self.mid in self.bot:
                        groups = self.client.getGroupIdsJoined()
                        if grup.id not in groups:
                            a = self.detectgroup(grup.id)
                            if False == a:
                                self.client.acceptGroupInvitationByTicket(grup.id,mid)
                        self.jqr = True
                    else:
                        d = self.detectgroup(grup.id)
                        if True == d:
                            self.client.leaveGroup(grup.id)
                        self.jqr = False
            elif text.lower().startswith('.rkickout'):
                if sender in self.sb[str(self.korban)]:
                    split = text.split(" ")
                    cust = split[1]
                    grup = split[2]
                    if self.client.limit == False:
                        cgroup = self.detectgroup(grup)
                        if True == cgroup:
                            try:self.client.kickoutFromGroup(grup,[cust])
                            except:self.broadcast(".rkickout {} {}".format(cust,group));self.client.limit = True
                    else:self.broadcast(".rkickout {} {}".format(cust,group))
            elif text.lower().startswith('.prokick'):
                if sender in self.sb[str(self.korban)]:
                    split = text.split(" ")
                    cust = split[1]
                    grup = split[2]
                    if self.on == True:
                        if self.client.limit == False:
                            self.botOnPro = True
                            self.client.kickoutFromGroup(grup,[cust])
                        else:
                            self.broadcast(".prokick {} {}".format(cust,grup))
                            self.botOnPro = False
                            self.on = False
            elif text.lower().startswith('.kickout'):
                if sender in self.sb[str(self.korban)]:
                    split = text.split(" ")
                    cust = split[1]
                    grup = split[2]
                    if self.client.limit == False:
                        if self.cek(cust):
                            self.black(cust)
                            if self.mainTampBl == True:
                                musuh = []
                                for sq in self.blacktamp:
                                    if cust in self.blacktamp[sq]:
                                        for x in self.blacktamp[sq]:
                                            musuh.append(x)
                                if musuh == []:
                                    self.client.kickoutFromGroup(grup,[cust])
                                else:
                                    try:self.client.specialKC(grup,musuh,[])
                                    except:self.broadcast(".kickout {} {}".format(cust,grup));self.client.limit = True
                            else:
                                try:self.client.kickoutFromGroup(grup,[cust])
                                except:self.broadcast(".kickout {} {}".format(cust,grup));self.client.limit = True
                    else:self.broadcast(".kickout {} {}".format(cust,grup))
            elif text.lower().startswith('.limit'):
                if sender in self.sb[str(self.korban)]:
                    split = text.split(" ")
                    grup = split[1]
                    pelaku = split[2]
                    threading.Thread(target = self.inputwarbot(grup,pelaku,sender)).start()
            elif text.lower()== '.change':
                if sender in self.sb[str(self.korban)]:
                    korban = self.korban
                    korban -= 1
                    self.korban = korban
                    self.client.sendMessage(to,"bekap {}".format(str(korban)))
    def accqr(self,gc,ticket):
        try:
            if self.jqr == True:
                grup = self.client.findGroupByTicket(ticket)
                groups = self.client.getGroupIdsJoined()
                if gc not in groups:
                    self.client.acceptGroupInvitationByTicket(grup.id,ticket)
                if self.main == True:
                    threading.Thread(target = self.dban(gc,)).start()
        except:pass
    def getLexe(self,op):
        if op.type == 130:
            if op.param1 not in self.Lexe["ljoin"]:self.Lexe["ljoin"][op.param1] = {}
            self.Lexe["ljoin"][op.param1][op.param2] = True
            return
        elif op.type in [124,123]:
            if op.param1 not in self.Lexe["linvite"]:self.Lexe["linvite"][op.param1] = {}
            if op.param3 == None:self.Lexe["linvite"][op.param1][op.param2] = True
            else:self.Lexe["linvite"][op.param1][op.param3] = True
            return
        elif op.type in [126,125]:
            if op.param1 not in self.Lexe["lcancel"]:self.Lexe["lcancel"][op.param1] = {}
            if op.param3 == None:self.Lexe["lcancel"][op.param1][op.param2] = True
            else:self.Lexe["lcancel"][op.param1][op.param3] = True
            return
        elif op.type in [133,132]:
            if op.param1 not in self.Lexe["lkick"]:self.Lexe["lkick"][op.param1] = {}
            if op.param3 == None:self.Lexe["lkick"][op.param1][op.param2] = True
            else:self.Lexe["lkick"][op.param1][op.param3] = True
            self.Lexe["auto"] = True
            return
        elif op.type == 61:
            if self.Lexe["auto"] == True:
                self.Lexe["auto"] = False
                return
            if op.param1 not in self.Lexe["lleave"]:self.Lexe["lleave"][op.param1] = {}
            self.Lexe["lleave"][op.param1][op.param2] = True
            return
    def warnormal(self, op):
        tempat=op.param1
        pelaku=op.param2
        korban=op.param3
        if op.type == 13 or op.type == 124:
            if self.type == 100:
                return
            if self.mid in korban:
                if self.cek(pelaku):
                    pass
                else:
                    threading.Thread(target = self.client.acceptGroupInvitation(tempat,)).start()
                    if self.type == self.capt:
                        if self.main == False:
                            if self.AllBotJoin == True:
                                D = self.client.getGroupWithoutMembers(tempat)
                                if D.preventedJoinByTicket == True:
                                    D.preventedJoinByTicket = False
                                self.client.updateGroup(D)
                                Ticket=self.client.reissueGroupTicket(tempat)
                                self.stayQr(Ticket)
                                self.invqr(tempat)
                return
            #if self.mid in op.param3:
                #if op.param2 in self.bots or op.param2 in self.owners:
                    #threading.Thread(target = self.client.acceptGroupInvitation(tempat,)).start()

            if self.main == True:
                if self.cek(pelaku):
                    for b in self.client.getGroup(tempat).invitee:
                        if b.mid in korban:
                            threading.Thread(target = self.client.cancelGroupInvitation(tempat,[b.mid])).start()
                    threading.Thread(target = self.kicking(tempat,pelaku)).start()
            else:
                if korban in self.bl:
                    if self.cek(pelaku):
                        self.black(pelaku)
                if self.type == self.capt:
                    if self.cek(pelaku):
                        xx = []
                        for b in self.client.getGroup(tempat).invitee:
                            if b.mid in korban:
                                xx.append(b.mid)
                        xx.append(pelaku)
                        self.btamp(tempat,xx)
            return
        elif op.type == 17 or op.type == 130:
            if self.main == True:
                if self.war[tempat] == True:
                    if self.cek(pelaku):
                        threading.Thread(target = self.kicklockqr(tempat,pelaku)).start()
            else:
                if self.type == self.capt:
                    if self.cek(pelaku):
                        if self.btamQr["status"] == True:
                            self.btamQr["user"].append(pelaku)
            return
        elif op.type == 11 or op.type == 122:
            if self.main == True:
                if self.war[tempat] == True:
                    if self.cek(pelaku):
                        threading.Thread(target = self.kicklockban(tempat,pelaku)).start()
            else:
                if self.type == self.capt:
                    if self.cek(pelaku):
                        C = self.client.getGroupWithoutMembers(tempat)
                        if C.preventedJoinByTicket == False:
                            if self.btamQr["status"] == False:
                                self.btamQr["status"] = True
                                self.btamQr["user"].append(pelaku)
                        else:
                            self.btamQr["status"] = False
                            self.btamp(tempat,self.btamQr["user"])
                            self.btamQr["user"] = []
            return
        elif op.type == 32 or op.type == 126:
            if self.main == True:
                if self.war[tempat] == True:
                    if korban in self.bots:
                        if self.cek(pelaku):
                            threading.Thread(target = self.kickinv(tempat,pelaku,korban)).start()
            return
        elif op.type == 19 or op.type == 133:
            if self.mid in korban:
                if self.cek(pelaku):self.main = True
                return
            if self.sb[str(self.korban)] in korban:
                if self.cek(pelaku):
                    if self.type == self.type:
                        threading.Thread(target = self.inputwarbot(tempat,pelaku,korban)).start()
            return
    def protect(self, op):
        if op.type == 0:
            return
        elif op.type == 13 or op.type == 124: #13
            tempat=op.param1
            pelaku=op.param2
            korban=op.param3
            if self.type == 100:
                return
            if self.mid in korban:
                self.client.acceptGroupInvitation(tempat)
                if self.acessInTeam(tempat,pelaku):
                    if self.kickall == True:
                        if op.param1 not in self.pro:
                            self.nuklir(tempat)
                    if self.type == self.capt:
                        if self.AllBotJoin == True:
                            D = self.client.getGroupWithoutMembers(tempat)
                            if D.preventedJoinByTicket == True:
                                D.preventedJoinByTicket = False
                            self.client.updateGroup(D)
                            Ticket=self.client.reissueGroupTicket(tempat)
                            self.stayQr(Ticket)
                            self.invqr(tempat)
                else:
                    self.client.leaveGroup(tempat)
                return
            if tempat in self.pro:
                if self.acessInTeam(tempat,pelaku):
                    self.ws(korban)
                    for b in self.client.getGroup(tempat).invitee:self.ws(b.mid)
                    if self.autoCancel == True:
                        user = []
                        for b in self.client.getGroup(tempat).invitee:
                            if b.mid in korban:
                                user.append(b.mid)
                        Auto_cancel = threading.Thread(target=self.autoccl, args=(tempat,user)).start()
                else:
                    if self.botOnPro == True:
                        threading.Thread(target = self.kicking(tempat,pelaku)).start()
                        for b in self.client.getGroup(tempat).invitee:
                            if b.mid in korban:
                                threading.Thread(target = self.client.cancelGroupInvitation(tempat,[b.mid])).start()
                                self.black(b.mid)
            else:
                if self.type == self.capt:
                    if self.cek(pelaku):
                        xx = []
                        for b in self.client.getGroup(tempat).invitee:
                            if b.mid in korban:
                                xx.append(b.mid)
                        xx.append(pelaku)
                        self.btamp(tempat,xx)
            return
        elif op.type == 32 or op.type == 126: #32
            tempat=op.param1
            pelaku=op.param2
            korban=op.param3
            if tempat in self.pro:
                if self.botOnPro == True:
                    threading.Thread(target = self.kickinginv(tempat,pelaku,korban)).start()
            return
        elif op.type == 11 or op.type == 122: #11
            tempat=op.param1
            pelaku=op.param2
            korban=op.param3
            if tempat in self.pro and self.userNotInAccess(tempat,pelaku):
                if self.botOnPro == True:
                    threading.Thread(target = self.kicklockqr(tempat,pelaku)).start()
            else:
                if self.type == self.capt:
                    C = self.client.getGroupWithoutMembers(tempat)
                    if C.preventedJoinByTicket == False:
                        if self.btamQr["status"] == False:
                            self.btamQr["status"] = True
                            self.btamQr["user"].append(pelaku)
                    else:
                        self.btamQr["status"] = False
                        self.btamp(tempat,self.btamQr["user"])
                        self.btamQr["user"] = []
            return
        elif op.type == 17 or op.type == 130: #17
            tempat=op.param1
            pelaku=op.param2
            if tempat in self.pro and self.cek(pelaku):
                if self.botOnPro == True:
                    threading.Thread(target = self.kicking(tempat,pelaku)).start()
            else:
                time.sleep(0.5)
                if pelaku in self.whitlist:
                    del self.setws["ws"][pelaku]
                if self.type == self.capt:
                    if self.cek(pelaku):
                        if self.btamQr["status"] == True:
                            self.btamQr["user"].append(pelaku)
            return
        elif op.type == 19 or op.type == 133: #19
            tempat=op.param1
            pelaku=op.param2
            korban=op.param3
            if self.type == 100:
                mem = [contact.mid for contact in self.client.getGroup(tempat).members]
                for bot in self.bots:
                    if bot in mem:
                        break
                    else:
                        if tempat in self.pro or tempat in self.gname:
                            if self.cek(pelaku):
                                self.client.acceptGroupInvitation(tempat)
                                self.inputwarbot(tempat,pelaku,korban)
                                time.sleep(0.2)
                                for u in self.owners:
                                    try:self.client.findAndAddContactsByMid(u)
                                    except:break
                                self.client.inviteIntoGroup(tempat,self.owners)
                                self.client.leaveGroup(tempat)
                return
            if tempat in self.pro:
                if self.type == self.type:
                    threading.Thread(target = self.kickpro(tempat,pelaku,korban)).start()
            else:
                if self.mid in korban:
                    if self.cek(pelaku):self.main = True
                    return
                if korban in self.sb[str(self.korban)]:
                    if self.cek(pelaku):
                        if self.type == self.type:
                            threading.Thread(target = self.inputwarbot(tempat,pelaku,korban)).start()
                if korban in self.owners:
                    threading.Thread(target = self.kickpro(tempat,pelaku,korban)).start()
                if korban in self.bots:
                    if self.ac == True:
                        A1 = threading.Thread(target=self.autoclearwar, args=(tempat,)).start()
                        self.ac = False
            return
    def botType(self,to):
        try:
            mem = [contact.mid for contact in self.client.getGroup(to).members]
            for bot in self.sb:
                if self.sb[bot] in mem:
                    if int(bot) == self.type:
                        if self.pro != {}:self.botOnPro = True
                    else:self.botOnPro = False
                    return int(bot)
        except:
            return self.type
    def btamp(self, to,bt=[]):
        if 4 <= len(bt):
            if len(self.blacktamp) <= 40:
                z = []
                if self.blacktamp == {}:
                    jsq = len(self.blacktamp)
                    jsq += 1
                    self.blacktamp[str(jsq)] = {}
                    for x in bt:
                        z.append(x)
                else:
                    jsq = len(self.blacktamp)
                    jsq += 1
                    self.blacktamp[str(jsq)] = {}
                    for mid in bt:
                        for sq in self.blacktamp:
                            if mid in self.blacktamp[sq]:
                                z = []
                                try:del self.blacktamp[str(jsq)]
                                except:pass
                                break
                            else:
                                z.append(mid)
                for w in z:
                    try:self.setbtamp['btamp'][str(jsq)][w] = True
                    except:pass
            else:self.btamQr["user"] = []
        else:self.btamQr["user"] = []
    def autoccl(self, tempat,user=[]):
        if self.type == self.capt:
            tb = 300
            tb += 60
            time.sleep(tb)
            korban = []
            for b in self.client.getGroup(tempat).invitee:
                if b.mid in user:
                    if b.mid not in self.owners and b.mid not in self.bots and b.mid not in self.staff and b.mid not in self.gtb and b.mid not in self.anti and b.mid not in self. fbot:
                        self.client.cancelGroupInvitation(tempat,[b.mid])
                        korban.append(b.mid)
            if korban == []:pass
            else:
                self.client.datamention(tempat,'Auto cancel members',korban)
                self.client.sendMessage(tempat,"Please contact the members for confrim")
        else:
            tb = 300
            for a in self.bots:
                tb += self.timebot
            time.sleep(tb)
            korban = []
            for b in self.client.getGroup(tempat).invitee:
                if b.mid in user:
                    if b.mid not in self.owners and b.mid not in self.bots and b.mid not in self.staff and b.mid not in self.gtb and b.mid not in self.anti and b.mid not in self. fbot:
                        self.client.cancelGroupInvitation(tempat,[b.mid])
                        korban.append(b.mid)
            if korban == []:pass
            else:
                self.client.datamention(tempat,'Auto cancel members',korban)
                self.client.sendMessage(tempat,"Please contact the members for confrim")
    def komenbot(self,op):
        global countKick
        global countInvite
        global countCancel
        if op.type == 0:
            return
        elif op.type == 15 or op.type == 61:
            if op.param2 in self.anti:
                if self.type == NOTIFIED_LEAVE_GROUP:
                    try:self.client.inviteIntoGroup(op.param1,[op.param2])
                    except:self.client.sendMessage(op.param1,"Contact",{'mid': op.param2},13);self.client.sendMessage(op.param1,"please invite bot 👆")
        elif op.type == 5:
            if op.param1 not in self.bots:
                self.client.findAndAddContactsByMid(op.param1)
        elif op.type == 12:
            countInvite += 1
        elif op.type == 18:
            countKick += 1
        elif op.type == 31:
            countCancel += 1
        elif op.type == 55:
            if op.param1 in self.Gid:
                if op.param2 not in self.Gid[op.param1]:
                    self.client.datamention(op.param1,'What are you looking at?',[op.param2])
                    self.Gid[op.param1].append(op.param2)
            if op.param2 in self.ban:
                self.client.kickoutFromGroup(op.param1,[op.param2])
        elif op.type == 26:
            try:threading.Thread(target = self.notified_receive_message(op,)).start()
            except Exception as e:
                if 'code=35' in str(e):
                    self.client.limit = True
                print(str(e))
            return
    
    
    
    